//
//  TabBarVc.swift
//  Medtime
//
//  Created by Saranya Ravi on 27/10/23.
//

import UIKit

class TabBarVc: UITabBarController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
       // setupTabBarItems()
    }
    
    func setupTabBarItems() {
        let homeImage = UIImage(named: "Home")!
        let addPillImage = UIImage(named: "AddPill")!
        let appointmentImage = UIImage(named: "Appointment")!
        let addPatientImage = UIImage(named: "AddPatient")!
   
        
        let resizedhome = resizeImage(image: homeImage, targetSize: CGSize(width: 30, height: 30))?.withRenderingMode(.alwaysTemplate)
        let resizedPill = resizeImage(image: addPillImage, targetSize: CGSize(width: 30, height: 30))?.withRenderingMode(.alwaysTemplate)
        let resizedAppointment = resizeImage(image: appointmentImage, targetSize: CGSize(width: 30, height: 30))?.withRenderingMode(.alwaysTemplate)
        let resizedPatient = resizeImage(image: addPatientImage, targetSize: CGSize(width: 30, height: 30))?.withRenderingMode(.alwaysTemplate)
        
       
        tabBar.items![0].image = resizedhome
        tabBar.items![1].image = resizedPill
        tabBar.items![2].image = resizedAppointment
        tabBar.items![3].image = resizedPatient
        
    }
}

