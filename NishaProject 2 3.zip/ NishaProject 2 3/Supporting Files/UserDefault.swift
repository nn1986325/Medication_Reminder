//
//  UserDefault.swift
//  building management
//
//  Created by SAIL on 09/10/23.
//

import Foundation

class UserDefaultsManager {
    
    static let shared = UserDefaultsManager()
    
    private let userDefaults = UserDefaults.standard
    
    private init() {}
    
    // MARK: - Save Data
    
    func setValue<T>(_ value: T, forKey key: String) {
        userDefaults.set(value, forKey: key)
    }
    func getValue<T>(forKey key: String) -> T? {
        return userDefaults.value(forKey: key) as? T
    }
    
    // MARK: - Remove Data (if needed)
    func removeValue(forKey key: String) {
        userDefaults.removeObject(forKey: key)
        
    }
    
}

