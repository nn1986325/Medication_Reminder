//
//  DataManager.swift
//  Medtime
//
//  Created by SAIL L1 on 08/02/24.
//


import UIKit




class DataManager {
    
  
        static let shared = DataManager()
        
        private init() {
            // Private initialization to ensure just one instance is created.
        }
    var doctorLoginId = String()
    var patientLoginId = String()
    var baseUrl = String()
    var patientImage = String()

   
    func sendMessage(title:String,message:String,navigation:UINavigationController) {
        
       
        let alertController = UIAlertController(title: "Message", message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        navigation.present(alertController, animated: false, completion: nil)
    }
}
