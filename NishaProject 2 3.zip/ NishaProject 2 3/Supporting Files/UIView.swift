//
//  UIView.swift
//  Pcos
//
//  Created by Karthik Babu on 01/10/23.
//

import Foundation
import UIKit
import UserNotifications

@IBDesignable extension UIView {
    @IBInspectable var cornerRadius: CGFloat {
        get { return layer.cornerRadius }
        set {
              layer.cornerRadius = newValue

              // If masksToBounds is true, subviews will be
              // clipped to the rounded corners.
              layer.masksToBounds = (newValue > 0)
        }
    }
}

@IBDesignable extension UIView {
    @IBInspectable var shadowRadius: CGFloat {
        get { return layer.shadowRadius }
        set { layer.shadowRadius = newValue }
    }

    @IBInspectable var shadowOpacity: CGFloat {
        get { return CGFloat(layer.shadowOpacity) }
        set { layer.shadowOpacity = Float(newValue) }
    }

    @IBInspectable var shadowOffset: CGSize {
        get { return layer.shadowOffset }
        set { layer.shadowOffset = newValue }
    }

    @IBInspectable var shadowColor: UIColor? {
        get {
            guard let cgColor = layer.shadowColor else {
                return nil
            }
            return UIColor(cgColor: cgColor)
        }
        set { layer.shadowColor = newValue?.cgColor }
    }
}

@IBDesignable extension UIView {
    @IBInspectable var borderColor: UIColor? {
        get {
            guard let cgColor = layer.borderColor else {
                return nil
            }
            return UIColor(cgColor: cgColor)
        }
        set { layer.borderColor = newValue?.cgColor }
    }

    @IBInspectable var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
}





class GradientView: UIView {
    private let gradientLayer = CAGradientLayer()

    var startColor: UIColor = .white {
        didSet {
            updateGradient()
        }
    }

    var endColor: UIColor = .white {
        didSet {
            updateGradient()
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }

    private func commonInit() {
        layer.insertSublayer(gradientLayer, at: 0)
        updateGradient()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer.frame = bounds
    }

    private func updateGradient() {
        gradientLayer.colors = [startColor.cgColor, endColor.cgColor]
    }
}


extension UIViewController {
    
    func loadImage(url: String, imageView: UIImageView?) {
        
        let baseURL = ServiceAPI.ipAddress
        
     
        guard let imageUrl = URL(string: baseURL + url) else {
            return
        }
        
      
        let task = URLSession.shared.dataTask(with: imageUrl) { (data, response, error) in
          
            guard error == nil, let imageData = data else {
                print("Error downloading image: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
           
            DispatchQueue.main.async {
                if let image = UIImage(data: imageData) {
                    // Set the loaded image to the UIImageView
                    imageView?.image = image
                }
            }
        }
        
        // Start the URL session task
        task.resume()
    }
    
    
  //  class NotificationManager {
//        func scheduleNotification(at time: String, title: String, body: String, identifier: String) {
//            DispatchQueue.main.async {
//
//
//           let dateFormatter = DateFormatter()
//           dateFormatter.dateFormat = "hh:mm a"
//
//           guard let fireDate = dateFormatter.date(from: time) else {
//               print("Invalid time format")
//               return
//           }
//
//           let calendar = Calendar.current
//           let dateComponents = calendar.dateComponents([.hour, .minute], from: fireDate)
//
//           let content = UNMutableNotificationContent()
//           content.title = title
//           content.body = body
//
//           // Set the sound for the notification
//           content.sound = UNNotificationSound.default
//
//           let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
//
//           let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
//
//           UNUserNotificationCenter.current().add(request) { (error) in
//               if let error = error {
//                   print("Error scheduling notification: \(error.localizedDescription)")
//               } else {
//                   print("Notification scheduled successfully")
//               }
//           }
//        }
//
//    }
    
    
     func scheduleNotifications(notificationData: [NotificationData]) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "hh:mm a"

        for data in notificationData {
            guard let fireDate = dateFormatter.date(from: data.time) else {
                print("Invalid time format for \(data.identifier)")
                continue
            }

            let calendar = Calendar.current
            let dateComponents = calendar.dateComponents([.hour, .minute], from: fireDate)

            let content = UNMutableNotificationContent()
            content.title = data.title
            content.body = data.body
          //  content.sound = UNNotificationSound.default
            
            content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "Kindly%20take%20your%20Med.mp3"))

            let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)

            let request = UNNotificationRequest(identifier: data.identifier, content: content, trigger: trigger)

            UNUserNotificationCenter.current().add(request) { (error) in
                if let error = error {
                    print("Error scheduling notification for \(data.identifier): \(error.localizedDescription)")
                } else {
                    print("Notification scheduled successfully for \(data.identifier)")
                }
                
            }
            
            
        }
        
    }
    
    

       
        class LoadingIndicator {

            static let shared = LoadingIndicator()

            private let activityIndicator: UIActivityIndicatorView = {
                let indicator = UIActivityIndicatorView(style: .large)
                indicator.color = UIColor.gray
                indicator.hidesWhenStopped = true
                return indicator
            }()

            private init() {}

            func showLoading(on view: UIView) {
                DispatchQueue.main.async {
                    self.activityIndicator.center = view.center
                    view.addSubview(self.activityIndicator)
                    self.activityIndicator.startAnimating()
                }
            }

            func hideLoading() {
                
                let mainQueue = DispatchQueue.main

                // Define a delay in seconds (e.g., 2 seconds)
                let delayInSeconds: Double = 0.3

                // Specify the deadline for the delay
                let deadline = DispatchTime.now() + delayInSeconds

                // Perform a task with a delay
                mainQueue.asyncAfter(deadline: deadline) {
                    // Code to be executed after the delay
                    self.activityIndicator.stopAnimating()
                    self.activityIndicator.removeFromSuperview()
                }
                
                
             
                  
                
            }
        }
      
          
    
    
}



class LineChartView: UIView {
    var datasets: [(dataPoints: [CGFloat], color: UIColor)] = [] // Array to store multiple datasets
    var showGrid = true // Property to toggle grid visibility
    var lineAnimationDuration: CFTimeInterval = 5.0 // Animation duration for drawing lines
    var xLabels: [String] = [] // X-axis labels
    var yLabels: [String] = [] // Y-axis labels
    var lineWidth = 2.0
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)

        // Calculate points for the data
        let maxDataValue = datasets.flatMap { $0.dataPoints }.max() ?? 0
        let scale = bounds.height / maxDataValue
        let stepX = bounds.width / CGFloat(datasets.first?.dataPoints.count ?? 1 - 1)

        // Create a CAShapeLayer for drawing the lines
        let lineLayer = CAShapeLayer()
        lineLayer.lineWidth = lineWidth
        lineLayer.strokeColor = UIColor.black.cgColor
        lineLayer.fillColor = UIColor.clear.cgColor
        self.layer.addSublayer(lineLayer)
        for dataset in datasets {
                    for (index, dataPoint) in dataset.dataPoints.enumerated() {
                        let x = CGFloat(index) * stepX
                        let y = bounds.height - dataPoint * scale

                        // Create a wrapper view for the circle layer
                        let circleView = UIView(frame: CGRect(x: x - 3, y: y - 3, width: 6, height: 6))
                        self.addSubview(circleView)

                        let circleLayer = CAShapeLayer()
                        let circlePath = UIBezierPath(ovalIn: CGRect(x: 0, y: 0, width: 6, height: 6))
                        circleLayer.path = circlePath.cgPath
                        circleLayer.fillColor = UIColor.red.cgColor
                        circleView.layer.addSublayer(circleLayer)

                        // Add tap gesture recognizer to the wrapper view
                        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
                        circleView.addGestureRecognizer(tapGesture)
                    }
                }
        // Draw the grid
        if showGrid {
            let numberOfGridLines = 5 // You can adjust this value
            let gridPath = UIBezierPath()

            for i in 0..<numberOfGridLines {
                let y = bounds.height - (CGFloat(i) / CGFloat(numberOfGridLines - 1)) * bounds.height
                gridPath.move(to: CGPoint(x: 0, y: y))
                gridPath.addLine(to: CGPoint(x: bounds.width, y: y))
            }

            let gridLayer = CAShapeLayer()
            gridLayer.path = gridPath.cgPath
            gridLayer.strokeColor = UIColor.lightGray.cgColor
            gridLayer.lineWidth = 0.5
            gridLayer.fillColor = UIColor.clear.cgColor
            self.layer.addSublayer(gridLayer)
        }

        // Draw the x-axis and y-axis lines
        let axisPath = UIBezierPath()

        // Draw the x-axis line
        axisPath.move(to: CGPoint(x: 0, y: bounds.height))
        axisPath.addLine(to: CGPoint(x: bounds.width, y: bounds.height))

        // Draw the y-axis line
        axisPath.move(to: CGPoint(x: 0, y: 0))
        axisPath.addLine(to: CGPoint(x: 0, y: bounds.height))

        let axisLayer = CAShapeLayer()
        axisLayer.path = axisPath.cgPath
        axisLayer.strokeColor = UIColor.black.cgColor
        axisLayer.lineWidth = 1.0
        axisLayer.fillColor = UIColor.clear.cgColor
        self.layer.addSublayer(axisLayer)

        // Draw the x-axis labels
        for (index, labelText) in xLabels.enumerated() {
            let x = CGFloat(index) * stepX
            let labelFrame = CGRect(x: x, y: bounds.height, width: stepX, height: 20)
            drawLabel(text: labelText, frame: labelFrame, alignment: .center)
        }

        // Draw the y-axis labels
        for (index, labelText) in yLabels.enumerated() {
            let y = bounds.height - (CGFloat(index) * (bounds.height / CGFloat(yLabels.count - 1)))
            let labelFrame = CGRect(x: -45, y: y - 10, width: 40, height: 20)
            drawLabel(text: labelText, frame: labelFrame, alignment: .right)
        }

        // Draw the line chart for each dataset with animation
        for dataset in datasets {
            let linePath = UIBezierPath()
            let lineLayer = CAShapeLayer()
            lineLayer.lineWidth = lineWidth
            lineLayer.strokeColor = dataset.color.cgColor
            lineLayer.fillColor = UIColor.clear.cgColor
            self.layer.addSublayer(lineLayer)

            for (index, dataPoint) in dataset.dataPoints.enumerated() {
                let x = CGFloat(index) * stepX
                let y = bounds.height - dataPoint * scale
                if index == 0 {
                    linePath.move(to: CGPoint(x: x, y: y))
                } else {
                    linePath.addLine(to: CGPoint(x: x, y: y))
                }
            }

            lineLayer.path = linePath.cgPath

            // Add animation for drawing lines
            let pathAnimation = CABasicAnimation(keyPath: "strokeEnd")
            pathAnimation.duration = lineAnimationDuration
            pathAnimation.fromValue = 0
            pathAnimation.toValue = 1
            lineLayer.add(pathAnimation, forKey: "strokeEndAnimation")
        }
    }

    func drawLabel(text: String, frame: CGRect, alignment: NSTextAlignment) {
        let label = UILabel(frame: frame)
        label.text = text
        label.textAlignment = alignment
        self.addSubview(label)
    }
    @objc func handleTap(_ gesture: UITapGestureRecognizer) {
        guard let circleView = gesture.view else { return }
        guard let circleLayer = circleView.layer.sublayers?.first as? CAShapeLayer else { return }

        // Find the index of the tapped circle
        guard let index = self.subviews.firstIndex(of: circleView) else { return }

        // Get the corresponding data value
        let datasetIndex = index / datasets.first!.dataPoints.count
        let dataPointIndex = index % datasets.first!.dataPoints.count
        let dataValue = datasets[datasetIndex].dataPoints[dataPointIndex]

        // Display the data value near the tapped dot
        let xPosition = circleView.frame.origin.x + circleView.frame.width + 5 // Adjust distance from dot
        let yPosition = circleView.frame.origin.y - 10 // Adjust vertical position
        
        // Check if the value label already exists
        if let existingLabel = self.subviews.first(where: { $0.tag == index }) as? UILabel {
            // If it exists, remove it
            existingLabel.removeFromSuperview()
        } else {
            // Create a new value label
            let valueLabel = UILabel(frame: CGRect(x: xPosition, y: yPosition, width: 50, height: 20)) // Customize frame as needed
            valueLabel.text = "\(dataValue)"
            valueLabel.textColor = UIColor.black
            valueLabel.font = UIFont.systemFont(ofSize: 5) // Adjust font size as needed
            valueLabel.textAlignment = .left
            valueLabel.backgroundColor = UIColor.white // Adjust background color as needed
            valueLabel.layer.cornerRadius = 5 // Adjust corner radius as needed
            valueLabel.layer.masksToBounds = true
            valueLabel.tag = index // Set a tag to identify the label
            addSubview(valueLabel) // Add the label as a subview of the LineChartView
        }
    }


}




//let dateFormatter = DateFormatter()
//dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
//let dateString = dateFormatter.string(from: Date())
//print(dateString)
