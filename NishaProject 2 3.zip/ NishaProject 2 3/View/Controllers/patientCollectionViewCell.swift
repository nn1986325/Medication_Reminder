//
//  patientCollectionViewCell.swift
//  Meditate
//
//  Created by ahamed basith on 16/10/2023.
//

import UIKit

class patientCollectionViewCell: UICollectionViewCell {
    
}
