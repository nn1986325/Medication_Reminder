//
//  adminViewController.swift
//  Medtime
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class adminViewController: UIViewController {
    
    
    
    @IBOutlet weak var mainView: UIView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
      
        
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
    }
    
    
    
//    func getLoginAPI() {
//    
//        let userInfo: [String: String] = [
//            "doctor_id": usernameTxt.text ?? "",
//            "password": passwordTxt.text ?? ""
//            ]
//
//        APIHandler().postAPIValues(type: Doctorlogin.self, apiUrl: ServiceAPI.login, method: "POST", formData: userInfo) { result in
//                        switch result {
//                        case .success(let data):
//                            if !data.success {
//                                DispatchQueue.main.async {
//                                    let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)
//                                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
//                                    alertController.addAction(cancelAction)
//                                    self.present(alertController, animated: true, completion: nil)
//                                }
//                            } else {
//                               self.sendEnterPatientVc()
//                            }
//
//                        case .failure(let error):
//                            DispatchQueue.main.async {
//                                let alertController = UIAlertController(title: "Message", message: "Error accuired", preferredStyle: .alert)
//                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
//                                alertController.addAction(cancelAction)
//                                self.present(alertController, animated: true, completion: nil)
//                            }
//                        }
//                    }
//                }
    
    @IBAction func docAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "DloginViewController") as! DloginViewController
        navigationController?.pushViewController(vc, animated: false)
    }
    
    @IBAction func patAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "patloginViewController") as! patloginViewController
        navigationController?.pushViewController(vc, animated: false)
        
    }
}
