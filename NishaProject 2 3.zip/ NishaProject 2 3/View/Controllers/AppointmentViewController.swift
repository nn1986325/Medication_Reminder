//
//  AppointmentViewController.swift
//  Medtime
//
//  Created by Sail L1 on 12/10/23.
//

import UIKit
struct details{
    let pimagee : UIImage!
    let patientidd : String!
    let patientnamee : String!
    let issuee : String!
    let acceptt : String!
    
}
class AppointmentViewController: UIViewController
{
    
    
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var segmentControll: UISegmentedControl!
    
    
    @IBOutlet weak var mainView: UIView!
    
    
    var appoinmentPending:Pending?
    var appoinmentApproved:Pending?
    var appoinmentAccept:Pending?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        tableview.delegate = self
        tableview.dataSource=self
        
        let cell = UINib(nibName: "PatientRecordTableViewCell", bundle: nil)
        self.tableview.register(cell, forCellReuseIdentifier: "cell")
        
        LoadingIndicator.shared.showLoading(on: self.view)
        getAppPedningAPI()
    }

    func getAppPedningAPI() {
      
    
        let userInfo: [String: String] = [
            "patient_id": DataManager.shared.patientLoginId,
            "issue":"diabeties",
            "name": "saman",
            "date":"2023/12/11"
            ]

        APIHandler().postAPIValues(type: Pending.self, apiUrl: ServiceAPI.appPendingStatus, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            
                          //  if data.status != "success"{
                            DispatchQueue.main.async {
                                LoadingIndicator.shared.hideLoading()
                                self.appoinmentPending = data
                                self.tableview.reloadData()
                                 }
                          print(data)
                        case .failure(_):
                            DispatchQueue.main.async {
                                LoadingIndicator.shared.hideLoading()
                            let alertController = UIAlertController(title: "Alert", message: "Something went wrong", preferredStyle: .alert)
                                 let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                 alertController.addAction(cancelAction)
                                 self.present(alertController, animated: false, completion: nil)
                            }
                        }
                            
                    }
            }
                

    func sendToAcceptAPI(patientId:String) {
    
        let userInfo: [String: String] = [
            "patient_id": patientId
           
            ]

        APIHandler().postAPIValues(type: Accept.self, apiUrl: ServiceAPI.appAcceptStatus, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                        DispatchQueue.main.async {
                            LoadingIndicator.shared.hideLoading()
                            self.getAppPedningAPI()
                            self.tableview.reloadData()
                            
                         
                            let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)
                                 let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                 alertController.addAction(cancelAction)
                                 self.present(alertController, animated: false, completion: nil)
                        }
                        //  print(data)
                        case .failure(let error):
                            LoadingIndicator.shared.hideLoading()
                            print(error)
                        }
                    }
                }
    
    
    
    func getAppApprovedAPI() {
    
        let userInfo: [String: String] = [
            "patient_id": DataManager.shared.patientLoginId,
            "issue":"diabeties",
            "name": "saman",
            "date":"2023/12/11"
            ]

        APIHandler().postAPIValues(type: Pending.self, apiUrl: ServiceAPI.appApprovedStatus, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            
                          //  if data.status != "success"{
                            DispatchQueue.main.async {
                                LoadingIndicator.shared.hideLoading()
                                self.appoinmentApproved = data
                                self.tableview.reloadData()
                                 }
                          print(data)
                        case .failure(let error):
                            print(error)
                            LoadingIndicator.shared.hideLoading()

                        }
                    }
        }

@IBAction func seg(_ sender: Any) {
    if segmentControll.selectedSegmentIndex == 0 {
        LoadingIndicator.shared.showLoading(on: self.view)
        getAppPedningAPI()
        tableview.reloadData()
    }
    else if segmentControll.selectedSegmentIndex == 1 {
     
        LoadingIndicator.shared.showLoading(on: self.view)
        getAppApprovedAPI()
        tableview.reloadData()
    }
}
}

extension AppointmentViewController : UITableViewDelegate, UITableViewDataSource {
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch segmentControll.selectedSegmentIndex{
        case 0:
            return appoinmentPending?.count ?? 0
        case 1:
            return appoinmentApproved?.count ?? 0
        default:
            break
        }
        return 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! PatientRecordTableViewCell
       
      

        switch segmentControll.selectedSegmentIndex {
            
        case 0 :
            let dict1 = appoinmentPending?[indexPath.row]
            cell.patientId.text = "ID: \(dict1?.patientID ?? "")"
            cell.patientName.text = dict1?.name
            cell.patientIssues.text = dict1?.issue
            cell.date.text = dict1?.date
            cell.acceptBtn.setTitle("Accept", for: .normal)
            
            
            cell.getPatientId = {
                if self.appoinmentPending?.isEmpty == false {
                if let id = self.appoinmentPending?[indexPath.row].patientID {
                    self.sendToAcceptAPI(patientId:id)
                }
                }
            }

        case 1 :
            let dict2 = appoinmentApproved?[indexPath.row]
            cell.patientId.text = dict2?.patientID
            cell.patientName.text = dict2?.name
            cell.patientIssues.text = dict2?.issue
            cell.date.text = dict2?.date
            cell.acceptBtn.setTitle("Approved", for: .normal)
            cell.getPatientId = {
//                if self.appoinmentPending?.isEmpty == false {
//                if let id = self.appoinmentPending?[indexPath.row].patientID {
//                    self.sendToAcceptAPI(patientId:id)
//                }
//                }
            }
        default:
            break
        }
        
        return cell
    }
func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return 180.0
}}

