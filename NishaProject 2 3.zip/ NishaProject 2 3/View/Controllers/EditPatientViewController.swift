//
//  EditPatientViewController.swift
//  Medtime
//
//  Created by SAIL L1 on 14/02/24.
//

import UIKit

class EditPatientViewController: UIViewController {
    
    
    @IBOutlet weak var patientIdFiled: UITextField!
    
    @IBOutlet weak var nameFiled: UITextField!
    
    
    @IBOutlet weak var ageFiled: UITextField!
    
    @IBOutlet weak var genderFiled: UITextField!
    
    
    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var phoneNumber: UITextField!
    
    
    var patientId = String()
    var name = String()
    var age = String()
    var gender = String()
    var number = String()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        patientIdFiled.text = patientId
        nameFiled.text = name
        ageFiled.text = age
        genderFiled.text = gender
        phoneNumber.text = number
        
        
        
        
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
    
    }
    
    
    
    @IBAction func backTapped(_ sender: Any) {
    
    self.navigationController?.popViewController(animated: false)
        
    }
    
    
    
    func updatePatientDetails() {
    
        let userInfo: [String: String] = [
            "patient_id": "SMCP001",
            "name": nameFiled.text ?? "",
            "age": ageFiled.text ?? "",
            "gender": genderFiled.text ?? "",
            "phone_number": phoneNumber.text ?? ""
            
            ]

        APIHandler().postAPIValues(type: docprofile.self, apiUrl: ServiceAPI.patientProfilUpadteUrl, method: "POST", formData: userInfo) { [self] result in
                        switch result {
                        case .success(let data):
                            if !data.success {
                              
                                DispatchQueue.main.async {
                                    LoadingIndicator.shared.hideLoading()
                                    let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)
                                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                    alertController.addAction(cancelAction)
                                    self.present(alertController, animated: true, completion: nil)
                                }
                            } else {
                                DispatchQueue.main.async {
                                    let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)
                                      let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                                          self.navigationController?.popViewController(animated: false)
                                      })
                                      alertController.addAction(okAction)
                                      let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: { _ in
                                          // Handle Cancel button tap if needed
                                      })
                                      alertController.addAction(cancelAction)
                                      self.present(alertController, animated: true, completion: nil)
                                  }
                            }

                        case .failure(let error):
                            LoadingIndicator.shared.hideLoading()
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Message", message: "Error accuired", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)
                                self.present(alertController, animated: true, completion: nil)
                            }
                        }
                    }
                }
    

  
    ///
    ///
    ///

    
    @IBAction func saveTapped(_ sender: Any) {
        if nameFiled.text ?? "" != "" && ageFiled.text ?? "" != "" && genderFiled.text ?? "" != "" && phoneNumber.text ?? "" != "" {
            LoadingIndicator.shared.showLoading(on: self.view)
            updatePatientDetails()
        }else {
            
            DispatchQueue.main.async {
                let alertController = UIAlertController(title: "Message", message: "Fill all the fileds", preferredStyle: .alert)
                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
            }
       }
        
        
    }
}
