//
//  DprofileViewController.swift
//  Medtime
//
//  Created by SAIL L1 on 27/10/23.
//

import UIKit

class DprofileViewController: UIViewController {
    
    @IBOutlet weak var doctorId: UITextField!
    
    @IBOutlet weak var subView: UIView!
    
    
    @IBOutlet weak var nameLbl: UITextField!
    
    @IBOutlet weak var spealityLbl: UITextField!
    
    
    
    @IBOutlet weak var genderLbl: UITextField!
    
    
    @IBOutlet weak var saveBtn: UIButton!
    
    
    var docProfile:DocProfile?
   
  
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        saveBtn.layer.cornerRadius = 10
        setupUI()
    }
 
    
    func  setupUI() {
        subView.clipsToBounds = true
        subView.layer.cornerRadius = 50
        subView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
    
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
        LoadingIndicator.shared.showLoading(on: self.view)
        getDoctorProfileAPI()
    }
    
    @IBAction func signOutTap(_ sender: Any) {
        

        DispatchQueue.main.async {
                    let alertController = UIAlertController(title: "Alert", message: "Do you want to logout?", preferredStyle: .alert)
                    
                  
                    let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                     let adminVC = self.storyboard?.instantiateViewController(identifier: "startViewController") as! startViewController
                        if let navigationController = self.navigationController {
                            navigationController.setViewControllers([adminVC], animated: true)
                        }
                    })
                    alertController.addAction(okAction)
                    
                 
                    let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: { _ in
                        
                    })
                    alertController.addAction(cancelAction)
                    
                    
                    self.present(alertController, animated: true, completion: nil)
                }
        
        
    }
    
    @IBAction func saveTapped(_ sender: Any) {
        
        
        let adminVC = self.storyboard?.instantiateViewController(identifier: "EditDoctorViewController") as! EditDoctorViewController
        adminVC.doctorIds = doctorId.text ?? ""
        adminVC.name = nameLbl.text ?? ""
        adminVC.speality = spealityLbl.text ?? ""
        adminVC.gender = genderLbl.text ?? ""
        
        self.navigationController?.pushViewController(adminVC, animated: false)
    
            
    }
    
    
    func getDoctorProfileAPI() {
      
        let userInfo: [String: String] = [
            "doctor_id": DataManager.shared.doctorLoginId,
    
            ]
        APIHandler().postAPIValues(type: DocProfile.self, apiUrl: ServiceAPI.doctorProfile, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            if !data.success {
                                DispatchQueue.main.async {
                                    LoadingIndicator.shared.hideLoading()
                                    let alertController = UIAlertController(title: "Alert", message: data.message, preferredStyle: .alert)

                                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                    alertController.addAction(cancelAction)

                                    self.present(alertController, animated: true, completion: nil)
                                }
                            } else {
                                LoadingIndicator.shared.hideLoading()
                                DispatchQueue.main.async {
                                    self.docProfile = data
                                    self.doctorId.text = self.docProfile?.data.doctorID
                                    self.nameLbl.text = self.docProfile?.data.doctorName
                                    self.genderLbl.text = self.docProfile?.data.gender
                                    self.spealityLbl.text = self.docProfile?.data.speciality
                                    
                                }
                                
                            }
                        case .failure(let error):
                            DispatchQueue.main.async {
                                LoadingIndicator.shared.hideLoading()
                                let alertController = UIAlertController(title: "Alert", message: "\(error)", preferredStyle: .alert)

                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)

                                self.present(alertController, animated: true, completion: nil)
                            }
                        }
                    }
        
    }
    
    

    @IBAction func backBtnTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
}

