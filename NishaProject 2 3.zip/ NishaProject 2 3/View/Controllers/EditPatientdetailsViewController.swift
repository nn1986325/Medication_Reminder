//
//  EditPatientdetailsViewController.swift
//  Medtime
//
//  Created by SAIL on 17/04/24.
//

import UIKit

class EditPatientdetailsViewController: UIViewController {

    @IBOutlet weak var patientIdfield: UITextField!
    
    @IBOutlet weak var treatmentLbl: UITextField!
    
    
    @IBOutlet weak var ageLbl: UITextField!
    
    
    @IBOutlet weak var genderLbl: UITextField!
    
    
    @IBOutlet weak var fbsLbl: UITextField!
    
    @IBOutlet weak var rbs: UITextField!
    
    
    @IBOutlet weak var numberLbl: UITextField!
    
    
    @IBOutlet weak var bpLbl: UITextField!
   
    
    
    @IBOutlet weak var ppbsLbl: UITextField!
    
    
    @IBOutlet weak var hba1cTxt: UITextField!
    
    
    
    @IBOutlet weak var attnameTxt: UITextField!
    
    
    @IBOutlet weak var relationTxt: UITextField!
    
    
    @IBOutlet weak var ageTxt: UITextField!
    
    
    @IBOutlet weak var genderTxt: UITextField!
    
    
    @IBOutlet weak var numberTxt: UITextField!
    
    
    @IBOutlet weak var nameLb: UITextField!
    
    
    @IBOutlet weak var tshVal: UITextField!
    
    
    var patinetId = String()
    var patientDetails:[PatientdetailData]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getAppApprovedAPI()
    }
    

    func editPatientDetails() {
    
        let userInfo: [String: String] = [
            "patient_id": DataManager.shared.patientLoginId,

            "name": nameLb.text ?? "",
            "age": ageLbl.text ?? "",
            "gender": genderLbl.text ?? "",
            "phone_number": numberLbl.text ?? "",
            "Treatment": treatmentLbl.text ?? "",
            "BP": bpLbl.text ?? "",
            "RBS": rbs.text ?? "",
            "TSH": tshVal.text ?? "",
            "FBS": fbsLbl.text ?? "",
            "ppbs": ppbsLbl.text ?? "",
            "HbA1c": hba1cTxt.text ?? "",
            "attender_name": attnameTxt.text ?? "",
            "relation_of_patient": relationTxt.text ?? "",
            "att_age": ageTxt.text ?? "",
            "att_gender": genderTxt.text ?? "",
            "att_phone_number": numberTxt.text ?? ""

            ]

        APIHandler().postAPIValues(type: Doctorlogin.self, apiUrl: ServiceAPI.EditpatientProfileDetails, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            
                          //  if data.status != "success"{
                         DispatchQueue.main.async {
                             LoadingIndicator.shared.hideLoading()
                       
                             let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)
                             let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                             alertController.addAction(cancelAction)
                             self.present(alertController, animated: false, completion: nil)
                              
                            }
                          print(data)
                        case .failure(let error):
                            LoadingIndicator.shared.hideLoading()
                            print(error)
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Alert", message: "Something went wrong", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)
                                self.present(alertController, animated: false, completion: nil)
                            }

                        }
                    }
        }
    
    
    func getAppApprovedAPI() {
    
        let userInfo: [String: String] = [
            "patient_id": DataManager.shared.patientLoginId,

            ]

        APIHandler().postAPIValues(type: Patientdetail.self, apiUrl: ServiceAPI.patientProfileDetails, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            
                          //  if data.status != "success"{
                         DispatchQueue.main.async {
                             if data.success == true {
                                 LoadingIndicator.shared.hideLoading()
                                 self.patientDetails = data.data
                                 LoadingIndicator.shared.showLoading(on: self.view)
                               
                                 self.nameLb.text = self.patientDetails?.first?.name
                                 self.patientIdfield.text = self.patientDetails?.first?.patientID
                                 self.ageLbl.text = "\(self.patientDetails?.first?.age ?? "")"
                                 self.genderLbl.text = self.patientDetails?.first?.gender
                                 self.numberLbl.text = self.patientDetails?.first?.phoneNumber
                                 self.treatmentLbl.text = self.patientDetails?.first?.treatment
                                 self.bpLbl.text = "\(self.patientDetails?.first?.bp ?? "")"
                                 self.rbs.text = "\(self.patientDetails?.first?.rbs ?? "")"
                                 self.tshVal.text = "\(self.patientDetails?.first?.tsh ?? "")"
                                 self.fbsLbl.text = self.patientDetails?.first?.fbs
                                 self.ppbsLbl.text = self.patientDetails?.first?.ppbs
                                 self.hba1cTxt.text = self.patientDetails?.first?.hbA1C
                                 self.attnameTxt.text = self.patientDetails?.first?.attenderName
                                 self.relationTxt.text = self.patientDetails?.first?.relationOfPatient
                                 
                                 
                                 self.ageTxt.text = "\(self.patientDetails?.first?.attAge ?? "")"
                                 self.genderTxt.text = self.patientDetails?.first?.attGender
                                 self.numberTxt.text = self.patientDetails?.first?.attPhoneNumber
                                 
//                                 self.loadImage(url:DataManager.shared.patientImage, imageView: self.profileImage)
                             }else {
                                 
                             }
                            }
                          print(data)
                        case .failure(let error):
                            LoadingIndicator.shared.hideLoading()
                            print(error)
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Alert", message: "Something went wrong", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)
                                self.present(alertController, animated: false, completion: nil)
                            }

                        }
                    }
        }
    
    
    @IBAction func submitTap(_ sender: Any) {
        editPatientDetails()
    }
    
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
}
