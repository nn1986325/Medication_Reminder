//
//  DhomeViewController.swift
//  Meditate
//
//  Created by ahamed basith on 15/10/2023.
//

import UIKit

class DhomeViewController: UIViewController {
    
    
    @IBOutlet weak var mainView: UIView!

    @IBOutlet weak var homeCollectionview: UICollectionView!
    
    var headerLabelText = "123"
  
    
    var appoinmentPending:Pending?
    var recentPatientDetails:RecentPatients?

    override func viewDidLoad() {
        super.viewDidLoad()
      
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        homeCollectionview.clipsToBounds = true
        homeCollectionview.layer.cornerRadius = 10
        homeCollectionview.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        setupUI()
        
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.minimumInteritemSpacing = 10
        flowLayout.minimumLineSpacing = 10
        flowLayout.scrollDirection = .vertical
        homeCollectionview.collectionViewLayout = flowLayout
       
    }
    
    func setupUI() {
        let cell = UINib(nibName: "ReminderCollectionViewCell", bundle: nil)
        homeCollectionview.register(cell, forCellWithReuseIdentifier: "reminderCell")
        let cellAppoint = UINib(nibName: "AppointmentCollectionViewCell", bundle: nil)
        homeCollectionview.register(cellAppoint, forCellWithReuseIdentifier: "appoinmentCell")
        
        let cellRecent = UINib(nibName: "RecentPatientCell", bundle: nil)
        homeCollectionview.register(cellRecent, forCellWithReuseIdentifier: "recentPatient")
        LoadingIndicator.shared.showLoading(on: self.view)
        
        
    }
    
     override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
         getrecentPatientAPI()
        getAppPedningAPI()
        self.tabBarController?.tabBar.isHidden = false
         
     }
    @IBAction func profileBtnTapped(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "DprofileViewController") as! DprofileViewController
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    
    
    
    func getAppPedningAPI() {
    
        let userInfo: [String: String] = [
            "patient_id": "SMCP001",
            "issue":"diabeties",
            "name": "saman",
            "date":"2023/12/11"
            ]

        APIHandler().postAPIValues(type: Pending.self, apiUrl: ServiceAPI.appPendingStatus, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            
                          //  if data.status != "success"{
                            DispatchQueue.main.async {
                                LoadingIndicator.shared.hideLoading()
                                self.appoinmentPending = data
                                self.homeCollectionview.reloadData()
                                 }
                          print(data)
                        case .failure(let error):
                            LoadingIndicator.shared.hideLoading()
                            print(error)
                        }
                    }
                }
 
    
    func getrecentPatientAPI() {
    
        let userInfo: [String: String] = [
            "": "",
           
            ]

        APIHandler().postAPIValues(type: RecentPatients.self, apiUrl: ServiceAPI.recentPatient, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            DispatchQueue.main.async {
                            if data.status == true {
                           
                                self.recentPatientDetails = data
                                self.homeCollectionview.reloadData()
                                 
                            }else {
                                self.homeCollectionview.reloadData()
                                let alertController = UIAlertController(title: "Alert", message: "Something went wrong", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)
                                self.present(alertController, animated: true, completion: nil)
                            }
                          print(data)
                            }
                        case .failure(let error):
                            print(error)
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Alert", message: "Error accuired", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)
                                self.present(alertController, animated: true, completion: nil)
                            }
                        }
                    }
                }
   

}
extension DhomeViewController: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 3
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        } else if section == 1 {
            return 1
        } else {
            return 1
        }
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "reminderCell", for: indexPath) as! ReminderCollectionViewCell
            cell.layer.cornerRadius = 10
            return cell
        } else if indexPath.section == 1 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "appoinmentCell", for: indexPath) as! AppointmentCollectionViewCell
            cell.profileView.isHidden = false
            cell.nameLbl.text = appoinmentPending?.first?.name
            cell.idLbl.text = appoinmentPending?.first?.patientID
            cell.dateLbl.text = appoinmentPending?.first?.date
            cell.reasonlbl.text = appoinmentPending?.first?.issue
            cell.acceptBtn.addTarget(self, action: #selector(setTap), for: .touchUpInside)
            if  appoinmentPending?.isEmpty == true {
                cell.profileView.isHidden = true
            }
            cell.layer.cornerRadius = 10
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "recentPatient", for: indexPath) as! RecentPatientCell
            cell.layer.cornerRadius = 10
            if let val =  recentPatientDetails?.data {
                cell.tableReload(value: val )
               
            }
            cell.addRecentPatient = {
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: "patientsViewController") as! patientsViewController
                self.navigationController?.pushViewController(vc, animated: false)
            }
            cell.seeAllButton.addTap {
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: "patientsViewController") as! patientsViewController
                self.navigationController?.pushViewController(vc, animated: false)
            }
            return cell
        }
    }
    


    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 200.0)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
            return CGSize(width: collectionView.frame.width, height: 10)
        }
    
    
    @objc func setTap() {
        
        self.tabBarController?.selectedIndex = 2
    }
}



