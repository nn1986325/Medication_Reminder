//
//  pill1ViewController.swift
//  Meditate
//
//  Created by SAIL on 14/10/23.
//

import UIKit

class pill1ViewController: UIViewController {
    
    
    
    @IBOutlet weak var topView: UIView!
    
    
    @IBOutlet weak var nameLbl: UITextField!
    
    
    @IBOutlet weak var ageLbl: UILabel!
    
    
    
    @IBOutlet weak var medicationLbl: UITextField!
    
    
    @IBOutlet weak var medicationFormField: UITextField!
    
    @IBOutlet weak var mainView: UIView!
    
    
    @IBOutlet weak var nextBtn: UIButton!
    
    
    @IBOutlet weak var morningBtn: UIButton!
    
    @IBOutlet weak var afterNoonBtn: UIButton!
    
    
    @IBOutlet weak var nightBtn: UIButton!
    
    
    @IBOutlet weak var idField: UITextField!
    
    
    
    var morning = String()
    var afterNoon = String()
    var night = String()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        morning = "1"
        afterNoon = "0"
        night = "0"
        
        
        nextBtn.layer.cornerRadius = 10
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        topView.layer.cornerRadius = 15
        
        
       
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = false
    }
  

    
   
    
    @IBAction func backBtnTapped(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func nextBtnTapped(_ sender: Any) {
       
        if nameLbl.text ?? "" != "" && idField.text ?? "" != "" && medicationLbl.text ?? "" != "" && medicationFormField.text ?? "" != ""  {
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "pill2ViewController") as! pill2ViewController
            vc.name = nameLbl.text ?? ""
            vc.patientId = idField.text ?? ""
            vc.medicationName = medicationLbl.text ?? ""
            vc.medicationForm = medicationFormField.text ?? ""
            vc.morningIntake = morning
            vc.afterNoonIntake = afterNoon
            vc.nightIntake = night
            self.navigationController?.pushViewController(vc, animated: false)
        }
        else{
            
            DispatchQueue.main.async {
                let alertController = UIAlertController(title: "Message", message: "Fill all the field", preferredStyle: .alert)
                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
            }
        }
        
        
        
    }
    
    
   

    @IBAction func mrgBtnTapped(_ sender: Any) {


        if morningBtn.imageView?.image == UIImage(named: "selectBtn") {
            morningBtn.setImage(UIImage(named: "unSelectBtn"), for: .normal)
            morning = "no"
            
        }else {
            morning = "yes"
          
            morningBtn.setImage(UIImage(named: "selectBtn"), for: .normal)
        }
    }

    @IBAction func afterNoonBtnTapped(_ sender: Any) {

        if afterNoonBtn.imageView?.image == UIImage(named: "selectBtn") {
         
            afterNoon = "no"
            afterNoonBtn.setImage(UIImage(named: "unSelectBtn"), for: .normal)
        }else {
          
            afterNoon = "yes"
            afterNoonBtn.setImage(UIImage(named: "selectBtn"), for: .normal)
        }
    }

    @IBAction func nightBtnTapped(_ sender: Any) {

        if nightBtn.imageView?.image == UIImage(named: "selectBtn") {
            nightBtn.setImage(UIImage(named: "unSelectBtn"), for: .normal)
            night = "no"
            
        }else {
            nightBtn.setImage(UIImage(named: "selectBtn"), for: .normal)
            night = "yes"
            
        }
    }
}
