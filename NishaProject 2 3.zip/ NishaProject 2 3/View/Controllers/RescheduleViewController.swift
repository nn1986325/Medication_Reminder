//
//  RescheduleViewController.swift
//  Medtime
//
//  Created by SAIL L1 on 27/10/23.
//

import UIKit

class RescheduleViewController: UIViewController {
    
    
    
    @IBOutlet weak var mainView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        mainView.layer.cornerRadius = 10
        mainView.layer.borderWidth = 1.0
        mainView.layer.borderColor = UIColor.lightGray.cgColor
    }

}
