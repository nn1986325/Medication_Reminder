//
//  AddPillReminderVc.swift
//  Meditate
//
//  Created by Saranya Ravi on 13/10/23.
//

import UIKit

class AddPillReminderVc: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    

//    func getLoginAPI() {
//    
//        let userInfo: [String: String] = [
//            "doctor_id": usernameTxt.text ?? "",
//            "password": passwordTxt.text ?? ""
//            ]
//
//        APIHandler().postAPIValues(type: Doctorlogin.self, apiUrl: ServiceAPI.login, method: "POST", formData: userInfo) { result in
//                        switch result {
//                        case .success(let data):
//                            if !data.success {
//                                DispatchQueue.main.async {
//                                    let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)
//                                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
//                                    alertController.addAction(cancelAction)
//                                    self.present(alertController, animated: true, completion: nil)
//                                }
//                            } else {
//                               self.sendEnterPatientVc()
//                            }
//
//                        case .failure(let error):
//                            DispatchQueue.main.async {
//                                let alertController = UIAlertController(title: "Message", message: "Error accuired", preferredStyle: .alert)
//                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
//                                alertController.addAction(cancelAction)
//                                self.present(alertController, animated: true, completion: nil)
//                            }
//                        }
//                    }
//                }

}
