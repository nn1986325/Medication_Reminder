//
//  UsersignupVC.swift
//  Medtime
//
//  Created by SAIL L1 on 22/11/23.
//

import UIKit

class UsersignupVC: UIViewController {

    @IBOutlet weak var nxtBtn: UIButton!
    @IBOutlet weak var mainView: UIView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        nxtBtn.layer.cornerRadius = 10

        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
    }
    
    @IBAction func nextBtnTapped(_ sender: Any) {
        
      
        self.navigationController?.popViewController(animated: false)
    }
    
}

