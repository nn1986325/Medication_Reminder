//
//  AddPatientVc.swift
//  Medtime
//
//  Created by SAIL L1 on 28/11/23.
//

import UIKit

class AddPatientVc: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    
    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var patientIdField: UITextField!
    
    
    @IBOutlet weak var patinetNameField: UITextField!
    
    
    @IBOutlet weak var ageField: UITextField!
    
    @IBOutlet weak var genderField: UITextField!
    
    @IBOutlet weak var numberField: UITextField!
    
    
    @IBOutlet weak var treatmentField: UITextField!
    
    
    @IBOutlet weak var bpField: UITextField!
    
    
    @IBOutlet weak var saveBtn: UIButton!
    
    @IBOutlet weak var tshField: UITextField!
    
    @IBOutlet weak var rbsField: UITextField!
    
    
    @IBOutlet weak var tftField: UITextField!
    
    
    @IBOutlet weak var fbsField: UITextField!
    
    
    
    @IBOutlet weak var ppbsField: UITextField!
    
    
    @IBOutlet weak var hba1cField: UITextField!
    
    
    @IBOutlet weak var urineRoutineFiled: UITextField!
    
    
    @IBOutlet weak var attendernamefield: UITextField!
    
    @IBOutlet weak var relationfield: UITextField!
    
    @IBOutlet weak var agefield: UITextField!
    
    @IBOutlet weak var genderfield: UITextField!
    
    @IBOutlet weak var numberfield: UITextField!
    
    
    @IBOutlet weak var patinetProfile: UIImageView!
    
    let imagePicker = UIImagePickerController()
    
    var selectedImage = [UIImage]()
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        selectedImage.removeAll()
        saveBtn.layer.cornerRadius = 10
        patinetProfile.layer.cornerRadius = 60
        
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        
            
    }
    
    
    func getLoginAPI() {
        
        if patientIdField.text ?? "" != "" && patinetNameField.text ?? "" != "" && agefield.text ?? "" != "" && genderfield.text ?? "" != "" &&
            numberfield.text ?? "" != "" && treatmentField.text ?? "" != "" && rbsField.text ?? "" != ""
            && bpField.text ?? "" != "" && attendernamefield.text ?? "" != "" && relationfield.text ?? "" != "" && agefield.text ?? "" != "" && genderfield.text ?? "" != "" && numberfield.text ?? "" != "" {
    
        let userInfo: [String: String] = [
            "patient_id": patientIdField.text ?? "",
            "name": patinetNameField.text ?? "",
            "age": ageField.text ?? "",
            "gender": genderField.text ?? "",
            "phone_number": numberField.text ?? "",
            "Treatment": treatmentField.text ?? "",
            "BP": bpField.text ?? "",
            "TSH": tshField.text ?? "",
            "RBS": rbsField.text ?? "",
            "TFT": tftField.text ?? "",
            "FBS": fbsField.text ?? "",
            "ppbs": ppbsField.text ?? "",
            "HbA1c": hba1cField.text ?? "",
            "urine_routine": urineRoutineFiled.text ?? "",
            "attender_name": attendernamefield.text ?? "",
            "relation_of_patient": relationfield.text ?? "",
            "att_age": agefield.text ?? "",
            "att_gender": genderfield.text ?? "",
            "att_phone_number": numberfield.text ?? ""
            
            ]
            
           
        
        APIHandler().postAPIValues(type: Addpatient.self, apiUrl: ServiceAPI.addPatient, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            if !data.addpatientInserted {
                                DispatchQueue.main.async {
                                    LoadingIndicator.shared.hideLoading()
                                    let alertController = UIAlertController(title: "Message", message: "Patient details not updated", preferredStyle: .alert)
                                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                    alertController.addAction(cancelAction)
                                    self.present(alertController, animated: true, completion: nil)
                                }
                            } else {
                                
                                DispatchQueue.main.async {
                                      let alertController = UIAlertController(title: "Alert", message: "Patient details updated sucessfully", preferredStyle: .alert)
                                      let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                                          self.patientIdField.text = ""
                                          self.patinetNameField.text = ""
                                          self.ageField.text = ""
                                          self.genderField.text = ""
                                          self.numberField.text = ""
                                          self.treatmentField.text = ""
                                          self.bpField.text = ""
                                          self.tshField.text = ""
                                          self.rbsField.text = ""
                                          self.tftField.text = ""
                                          self.fbsField.text = ""
                                          self.ppbsField.text = ""
                                          self.hba1cField.text = ""
                                          self.urineRoutineFiled.text = ""
                                          self.attendernamefield.text = ""
                                          self.relationfield.text = ""
                                          self.agefield.text = ""
                                          self.genderfield.text = ""
                                          self.numberfield.text = ""
                                          if let tab = self.tabBarController {
                                              tab.selectedIndex = 0
                                          }
                                      })
                                      alertController.addAction(okAction)
                                      self.present(alertController, animated: true, completion: nil)
                                  }
                            }

                        case .failure(let error):
                            print(error)
                            LoadingIndicator.shared.hideLoading()
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Message", message: "Error accuired", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)
                                self.present(alertController, animated: true, completion: nil)
                            }
                        }
                    }
                }
                else {
           DispatchQueue.main.async {
            let alertController = UIAlertController(title: "Message", message: "Fill important fields", preferredStyle: .alert)
            let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(cancelAction)
            self.present(alertController, animated: true, completion: nil)
            }
        }
    }
   
    @IBAction func saveBtnTapped(_ sender: Any) {
        
       
       
        if patientIdField.text ?? "" != "" && patinetNameField.text ?? "" != "" && ageField.text ?? "" != "" && genderField.text ?? "" != "" && numberField.text ?? "" != "" && treatmentField.text ?? "" != "" && bpField.text ?? "" != "" && tshField.text ?? "" != "" && rbsField.text ?? "" != "" && tftField.text ?? "" != "" && fbsField.text ?? "" != "" && ppbsField.text ?? "" != "" && hba1cField.text ?? "" != "" && urineRoutineFiled.text ?? "" != "" && attendernamefield.text ?? "" != "" && relationfield.text ?? "" != "" && agefield.text ?? "" != "" && genderfield.text ?? "" != "" && numberfield.text ?? "" != ""{
          
            if patinetProfile.image != nil {
                
                LoadingIndicator.shared.showLoading(on: self.view)
                getLoginAPI()
            }else {
                DispatchQueue.main.async {
                    let alertController = UIAlertController(title: "Message", message: "Please upload profile image", preferredStyle: .alert)
                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }else {
            
            
                DispatchQueue.main.async {
                    let alertController = UIAlertController(title: "Alert", message: "fill all the fields", preferredStyle: .alert)
                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
            
        }

    }
    
    

    
    
    @IBAction func updateProfileTap(_ sender: Any) {
        
        presentImagePicker()
    }
    
    
    func addImage() {
           
           let apiURL = ServiceAPI.uploadImageUrl
           print("API URL:", apiURL)

           let boundary = UUID().uuidString
           var request = URLRequest(url: URL(string: apiURL)!)
           request.httpMethod = "POST"
           request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
           var body = Data()
           let formData: [String: String] = [
               "patient_id": patientIdField.text ?? "",
             
           ]

           for (key, value) in formData {
               body.append(contentsOf: "--\(boundary)\r\n".utf8)
               body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
               body.append(contentsOf: "\(value)\r\n".utf8)
           }


           let fieldNames = ["image"]

           for (index, image) in selectedImage.enumerated() {
               let fieldName = fieldNames[index]

               let imageData = image.jpegData(compressionQuality: 0.8)!
               body.append(contentsOf: "--\(boundary)\r\n".utf8)
               body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
               body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
               body.append(contentsOf: imageData)
               body.append(contentsOf: "\r\n".utf8)


           }


           // Add closing boundary
           body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body

           request.httpBody = body

           let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
               if let error = error {
                   print("Error: \(error)")
                   // Handle the error, e.g., show an alert to the user
                   return
               }

               if let httpResponse = response as? HTTPURLResponse {
                   print("Status code: \(httpResponse.statusCode)")

                   if let data = data {
                       print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                       // You can perform further processing here
                   }
               }
           }

           task.resume()
       }

    
    func presentImagePicker() {
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallery()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera not available")
        }
    }
    
    func openGallery() {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
          if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
              patinetProfile.image = pickedImage
              selectedImage.append(pickedImage)
              addImage()
          }
          
          picker.dismiss(animated: true, completion: nil)
      }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
}

