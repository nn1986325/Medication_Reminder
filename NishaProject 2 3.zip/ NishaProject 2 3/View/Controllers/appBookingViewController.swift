//
//  AppBookingViewController.swift
//  Medtime
//
//  Created by SAIL L1 on 14/12/23.
//

import UIKit

class AppBookingViewController: UIViewController {
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    


}
