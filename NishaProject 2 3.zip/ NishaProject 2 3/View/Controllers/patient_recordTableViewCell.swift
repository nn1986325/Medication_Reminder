//
//  patient_recordTableViewCell.swift
//  Medtime
//
//  Created by Sail L1 on 12/10/23.
//

import UIKit

class patient_recordTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var accept: UIButton!
    @IBOutlet weak var pimage: UIImageView!
    @IBOutlet weak var patientid: UILabel!
    @IBOutlet weak var patientname: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var issue: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }


}
