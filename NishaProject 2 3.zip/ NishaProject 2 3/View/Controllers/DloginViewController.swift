//
//  DloginViewController.swift
//  Meditate
//
//  Created by ahamed basith on 15/10/2023.
//

import UIKit

class DloginViewController: UIViewController {

    @IBOutlet weak var usernameTxt: UITextField!
    
    @IBOutlet weak var passwordTxt: UITextField!
    
    
    @IBOutlet weak var eyeBtn: UIButton!
    var doctorID = ""
    var loginmodel : Doctorlogin!
    @IBOutlet weak var mainView: UIView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        passwordTxt.isSecureTextEntry = true
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
    }
    @IBAction func loginbtn(_ sender: Any) {
        
        if usernameTxt.text == "" || passwordTxt.text == "" {
            let alert = UIAlertController(title: "Alert", message: "Textfield is Empty", preferredStyle: UIAlertController.Style.alert)
            let alertAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(alertAction)
            present(alert, animated: false)
            
        } else {
            LoadingIndicator.shared.showLoading(on: self.view)
            getLoginAPI()

        }
        
    }
    @IBAction func Dfrgtbtn(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "PforgetpwdViewController") as! PforgetpwdViewController
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    
    
    @IBAction func backBtnTapped(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
        
    }
    
    
    
    @IBAction func signUpTapped(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "UsersignupVC") as! UsersignupVC
        self.navigationController?.pushViewController(vc, animated: false)
    }
    @IBAction func showPassTapped(_ sender: Any) {
        
        if passwordTxt.isSecureTextEntry == false {
            passwordTxt.isSecureTextEntry = true
        }else {
            passwordTxt.isSecureTextEntry = false
        }
    }
    
    
    func getLoginAPI() {
    
        let userInfo: [String: String] = [
            "doctor_id": usernameTxt.text ?? "",
            "password": passwordTxt.text ?? ""
            ]
        
        APIHandler().postAPIValues(type: Doctorlogin.self, apiUrl: ServiceAPI.login, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            if !data.success {
                                
                                DispatchQueue.main.async { [self] in
                                    LoadingIndicator.shared.hideLoading()
                                    let alertController = UIAlertController(title: "Message", message:"Something went wrong", preferredStyle: .alert)
                                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                    alertController.addAction(cancelAction)
                                    self.present(alertController, animated: false, completion: nil)
                                }
                            } else {
                               self.sendEnterPatientVc()
                            }

                        case .failure(let error):
                            print(error)
                            LoadingIndicator.shared.hideLoading()
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Message", message: "Error accuired", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)
                                self.present(alertController, animated: false, completion: nil)
                            }
                        }
                    }
                }
    
    func sendEnterPatientVc() {
     
        DispatchQueue.main.async {
            UserDefaults.standard.set(self.usernameTxt.text ?? "" , forKey: "DoctorID")
            DataManager.shared.doctorLoginId = self.usernameTxt.text ?? ""
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "TabBarVc") as! TabBarVc
            
            self.navigationController?.pushViewController(vc, animated: false)
        }
       }
    }


