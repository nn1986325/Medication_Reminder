//
//  ReminderImageCell.swift
//  Medtime
//
//  Created by SAIL L1 on 16/11/23.
//

import UIKit

class ReminderImageCell: UICollectionViewCell {
    
    
    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var bannerImagew: UIImageView!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        mainView.layer.cornerRadius = 10
    }

}
