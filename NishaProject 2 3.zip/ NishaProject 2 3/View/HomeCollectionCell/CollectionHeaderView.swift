//
//  CollectionHeaderView.swift
//  Medtime
//
//  Created by SAIL on 10/11/23.
//

import UIKit

class CollectionHeaderView: UICollectionReusableView {
    
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
