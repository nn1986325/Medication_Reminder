//
//  HederCell.swift
//  Medtime
//
//  Created by SAIL on 10/11/23.
//

import UIKit

class HederCell: UICollectionReusableView {
    
    
    @IBOutlet weak var headerLbl: UILabel!
    
    
    
    static let reuseIdentifier = "HederCell"
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
