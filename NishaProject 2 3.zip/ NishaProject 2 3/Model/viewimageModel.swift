//
//  viewimageModel.swift
//  Medtime
//
//  Created by SAIL L1 on 08/02/24.
//

import Foundation
struct viewimageModel: Codable {
    let status: Bool
    let message: String
    let images: [String]
}
