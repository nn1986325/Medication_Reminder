//
//  loginResponse.swift
//  Medtime
//
//  Created by Saranya Ravi on 26/10/23.
//

import UIKit

struct loginResponse: Codable {
    var success: Bool?
    var message: String?
    var data: [Datum]?
}
struct Datum: Codable {
    var sNo, username, password : String?
    enum CodingKeys: String, CodingKey {
        case sNo = "s_no"
        case username, password
    }
}


struct Medicationdetail: Codable {
    let patientID, medicationName: String
    let morning, afternoon, night: Int

    enum CodingKeys: String, CodingKey {
        case patientID = "patient_id"
        case medicationName = "medication_name"
        case morning, afternoon, night
    }
}

typealias Medicationdetails = [Medicationdetail]



struct PatientProfile: Codable {
  let status: String
  let data: [PatientProfileData]
}

// MARK: - Datum
struct PatientProfileData: Codable {
  let patientID, image: String

  enum CodingKeys: String, CodingKey {
      case patientID = "patient_id"
      case image
      
  }
}
