//
//  docprofilemdel.swift
//  Medtime
//
//  Created by SAIL L1 on 09/12/23.
//

import Foundation

// MARK: - Welcome
struct docprofile: Codable {
    let success: Bool
    let message: String
}



struct Patientprofile: Codable {
    let success: Bool
    let data: DataClass
    let message: String
}

// MARK: - DataClass
struct DataClass: Codable {
    let sNo: Int
    let patientID, name: String
    let age: String
    let gender, phoneNumber, image: String

    enum CodingKeys: String, CodingKey {
        case sNo = "s_no"
        case patientID = "patient_id"
        case name, age, gender
        case phoneNumber = "phone_number"
        case image
       
    }
}



struct Status: Codable {
    let data: [Approved]
}

struct Approved: Codable {
    let sNo: Int
    let patientID, name, issue, date: String
    let status: String

    enum CodingKeys: String, CodingKey {
        case sNo = "s_no"
        case patientID = "patient_id"
        case name, issue, date, status
    }
}
