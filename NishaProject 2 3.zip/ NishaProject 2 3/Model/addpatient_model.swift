//
//  addpatient_model.swift
//  Medtime
//
//  Created by SAIL L1 on 08/12/23.
//

import Foundation

struct Welcome: Codable {
    let userPasswordUpdated, userInserted, patientdetailsInserted, addpatientInserted: Bool
    let pProfileInserted: Bool

    enum CodingKeys: String, CodingKey {
        case userPasswordUpdated = "user_password_updated"
        case userInserted = "user_inserted"
        case patientdetailsInserted = "patientdetails_inserted"
        case addpatientInserted = "addpatient_inserted"
        case pProfileInserted = "p_profile_inserted"
    }
}



struct PendingElement: Codable {
    let sNo: Int
    let patientID, name, issue, date: String
    let status: String

    enum CodingKeys: String, CodingKey {
        case sNo = "s_no"
        case patientID = "patient_id"
        case name, issue, date, status
    }
}

typealias Pending = [PendingElement]


struct Accept: Codable {
    let status, message: String
}



struct RecentPatients: Codable {
    let status: Bool
    let message: String
    let data: [RecentPatientData]
}

struct RecentPatientData: Codable {
    let patientID: String

    enum CodingKeys: String, CodingKey {
        case patientID = "patient_id"
    }
}
