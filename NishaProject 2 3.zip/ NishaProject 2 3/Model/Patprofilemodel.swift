//
//  Patprofilemodel.swift
//  Medtime
//
//  Created by SAIL L1 on 09/12/23.
//

import Foundation



//struct Patientdetail: Codable {
//    let sNo: Int
//    let patientID, name: String
//    let age: Int
//    let gender, phoneNumber, treatment: String
//    let bp, tsh, tft: Int
//    let fbs, ppbs, RBS, hbA1C, urineRoutine: String
//    let attenderName, relationOfPatient: String
//    let attAge: Int
//    let attGender, attPhoneNumber: String
//    let image:String?
//
//    enum CodingKeys: String, CodingKey {
//        case sNo = "s_no"
//        case patientID = "patient_id"
//        case name, age, gender
//        case phoneNumber = "phone_number"
//        case treatment = "Treatment"
//        case bp = "BP"
//        case tsh = "TSH"
//        case tft = "TFT"
//        case fbs = "FBS"
//        case ppbs = "ppbs"
//        case RBS = "RBS"
//        case hbA1C = "HbA1c"
//        case urineRoutine = "urine_routine"
//        case attenderName = "attender_name"
//        case relationOfPatient = "relation_of_patient"
//        case attAge = "att_age"
//        case attGender = "att_gender"
//        case attPhoneNumber = "att_phone_number"
//        case image
//        
//    }
//}

struct Patientdetail: Codable {
    let success: Bool
    let data: [PatientdetailData]
}

// MARK: - Datum
struct PatientdetailData: Codable {
    let sNo: Int
    let patientID, name, age, gender: String
    let phoneNumber, treatment, bp, tsh: String
    let rbs, fbs, ppbs, hbA1C: String
    let attenderName, relationOfPatient, attAge, attGender: String
    let attPhoneNumber, image: String

    enum CodingKeys: String, CodingKey {
        case sNo = "s_no"
        case patientID = "patient_id"
        case name, age, gender
        case phoneNumber = "phone_number"
        case treatment = "Treatment"
        case bp = "BP"
        case tsh = "TSH"
        case rbs = "RBS"
        case fbs = "FBS"
        case ppbs
        case hbA1C = "HbA1c"
        case attenderName = "attender_name"
        case relationOfPatient = "relation_of_patient"
        case attAge = "att_age"
        case attGender = "att_gender"
        case attPhoneNumber = "att_phone_number"
        case image
    }
}

//typealias Patientdetails = [Patientdetail]

struct NotifyValue: Codable {
    let status: String
    let data: [NotifyValueData]
}

// MARK: - Datum
struct NotifyValueData: Codable {
    let sNo: Int
    let patientID, date, medicineTaken: String

    enum CodingKeys: String, CodingKey {
        case sNo = "s_no"
        case patientID = "patient_id"
        case date
        case medicineTaken = "medicine_taken"
    }
}



struct MedicationHomepage: Codable {
    let medicationDetails: MedicationDetails

    enum CodingKeys: String, CodingKey {
        case medicationDetails = "medication_details"
    }
}

// MARK: - MedicationDetails
struct MedicationDetails: Codable {
    let firstIntake, secondIntake, thirdIntake: [Intake]

    enum CodingKeys: String, CodingKey {
        case firstIntake = "first_intake"
        case secondIntake = "second_intake"
        case thirdIntake = "third_intake"
    }
}

// MARK: - Intake
struct Intake: Codable {
    let medicationName: String
    let beforeFood, afterFood: Int
    let timing: String

    enum CodingKeys: String, CodingKey {
        case medicationName = "medication_name"
        case beforeFood = "before_food"
        case afterFood = "after_food"
        case timing = "Timing"
    }
}




struct LineGraph: Codable {
    let status, message: String
    let hbA1CDates: [HbA1CDate]

    enum CodingKeys: String, CodingKey {
        case status, message
        case hbA1CDates = "HbA1c_dates"
    }
}

struct HbA1CDate: Codable {
    let hbA1C, date: String

    enum CodingKeys: String, CodingKey {
        case hbA1C = "HbA1c"
        case date
    }
}
