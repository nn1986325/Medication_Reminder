//
//  UIView.swift
//  Pcos
//
//  Created by Karthik Babu on 01/10/23.
//

import Foundation
import UIKit
import UserNotifications

@IBDesignable extension UIView {
    @IBInspectable var cornerRadius: CGFloat {
        get { return layer.cornerRadius }
        set {
              layer.cornerRadius = newValue

              // If masksToBounds is true, subviews will be
              // clipped to the rounded corners.
              layer.masksToBounds = (newValue > 0)
        }
    }
}

@IBDesignable extension UIView {
    @IBInspectable var shadowRadius: CGFloat {
        get { return layer.shadowRadius }
        set { layer.shadowRadius = newValue }
    }

    @IBInspectable var shadowOpacity: CGFloat {
        get { return CGFloat(layer.shadowOpacity) }
        set { layer.shadowOpacity = Float(newValue) }
    }

    @IBInspectable var shadowOffset: CGSize {
        get { return layer.shadowOffset }
        set { layer.shadowOffset = newValue }
    }

    @IBInspectable var shadowColor: UIColor? {
        get {
            guard let cgColor = layer.shadowColor else {
                return nil
            }
            return UIColor(cgColor: cgColor)
        }
        set { layer.shadowColor = newValue?.cgColor }
    }
}

@IBDesignable extension UIView {
    @IBInspectable var borderColor: UIColor? {
        get {
            guard let cgColor = layer.borderColor else {
                return nil
            }
            return UIColor(cgColor: cgColor)
        }
        set { layer.borderColor = newValue?.cgColor }
    }

    @IBInspectable var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
}





class GradientView: UIView {
    private let gradientLayer = CAGradientLayer()

    var startColor: UIColor = .white {
        didSet {
            updateGradient()
        }
    }

    var endColor: UIColor = .white {
        didSet {
            updateGradient()
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }

    private func commonInit() {
        layer.insertSublayer(gradientLayer, at: 0)
        updateGradient()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer.frame = bounds
    }

    private func updateGradient() {
        gradientLayer.colors = [startColor.cgColor, endColor.cgColor]
    }
}


extension UIViewController {
    
    func loadImage(url: String, imageView: UIImageView?) {
        
        let baseURL = ServiceAPI.ipAddress
        
     
        guard let imageUrl = URL(string: baseURL + url) else {
            return
        }
        
      
        let task = URLSession.shared.dataTask(with: imageUrl) { (data, response, error) in
          
            guard error == nil, let imageData = data else {
                print("Error downloading image: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
           
            DispatchQueue.main.async {
                if let image = UIImage(data: imageData) {
                    // Set the loaded image to the UIImageView
                    imageView?.image = image
                }
            }
        }
        
        // Start the URL session task
        task.resume()
    }
    
    
  //  class NotificationManager {
//        func scheduleNotification(at time: String, title: String, body: String, identifier: String) {
//            DispatchQueue.main.async {
//
//
//           let dateFormatter = DateFormatter()
//           dateFormatter.dateFormat = "hh:mm a"
//
//           guard let fireDate = dateFormatter.date(from: time) else {
//               print("Invalid time format")
//               return
//           }
//
//           let calendar = Calendar.current
//           let dateComponents = calendar.dateComponents([.hour, .minute], from: fireDate)
//
//           let content = UNMutableNotificationContent()
//           content.title = title
//           content.body = body
//
//           // Set the sound for the notification
//           content.sound = UNNotificationSound.default
//
//           let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
//
//           let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
//
//           UNUserNotificationCenter.current().add(request) { (error) in
//               if let error = error {
//                   print("Error scheduling notification: \(error.localizedDescription)")
//               } else {
//                   print("Notification scheduled successfully")
//               }
//           }
//        }
//
//    }
    
    
     func scheduleNotifications(notificationData: [NotificationData]) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "hh:mm a"

        for data in notificationData {
            guard let fireDate = dateFormatter.date(from: data.time) else {
                print("Invalid time format for \(data.identifier)")
                continue
            }

            let calendar = Calendar.current
            let dateComponents = calendar.dateComponents([.hour, .minute], from: fireDate)

            let content = UNMutableNotificationContent()
            content.title = data.title
            content.body = data.body
          //  content.sound = UNNotificationSound.default
            
            content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "Kindly%20take%20your%20Med.mp3"))

            let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)

            let request = UNNotificationRequest(identifier: data.identifier, content: content, trigger: trigger)

            UNUserNotificationCenter.current().add(request) { (error) in
                if let error = error {
                    print("Error scheduling notification for \(data.identifier): \(error.localizedDescription)")
                } else {
                    print("Notification scheduled successfully for \(data.identifier)")
                }
                
            }
            
            
        }
        
    }
    
    
//     func scheduleNotifications(at times: [String], titles: [String], bodies: [String], identifiers: [String]) {
//        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = "hh:mm a"
//
//        guard times.count == titles.count, titles.count == bodies.count, bodies.count == identifiers.count else {
//            print("Array counts do not match")
//            return
//        }
//
//        for (index, time) in times.enumerated() {
//            guard let fireDate = dateFormatter.date(from: time) else {
//                print("Invalid time format for index \(index)")
//                continue
//            }
//
//            let calendar = Calendar.current
//            let dateComponents = calendar.dateComponents([.hour, .minute], from: fireDate)
//
//            let content = UNMutableNotificationContent()
//            content.title = titles[index]
//            content.body = bodies[index]
//
//            // Set the sound for the notification
//            content.sound = UNNotificationSound.default
//
//            let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
//
//            let request = UNNotificationRequest(identifier: identifiers[index], content: content, trigger: trigger)
//
//            UNUserNotificationCenter.current().add(request) { (error) in
//                if let error = error {
//                    print("Error scheduling notification for index \(index): \(error.localizedDescription)")
//                } else {
//                    print("Notification scheduled successfully for index \(index)")
//                }
//            }
//        }
//
//     }
       
        class LoadingIndicator {

            static let shared = LoadingIndicator()

            private let activityIndicator: UIActivityIndicatorView = {
                let indicator = UIActivityIndicatorView(style: .large)
                indicator.color = UIColor.gray
                indicator.hidesWhenStopped = true
                return indicator
            }()

            private init() {}

            func showLoading(on view: UIView) {
                DispatchQueue.main.async {
                    self.activityIndicator.center = view.center
                    view.addSubview(self.activityIndicator)
                    self.activityIndicator.startAnimating()
                }
            }

            func hideLoading() {
                
                let mainQueue = DispatchQueue.main

                // Define a delay in seconds (e.g., 2 seconds)
                let delayInSeconds: Double = 0.3

                // Specify the deadline for the delay
                let deadline = DispatchTime.now() + delayInSeconds

                // Perform a task with a delay
                mainQueue.asyncAfter(deadline: deadline) {
                    // Code to be executed after the delay
                    self.activityIndicator.stopAnimating()
                    self.activityIndicator.removeFromSuperview()
                }
                
                
             
                  
                
            }
        }
      
          
    
    
}






//let dateFormatter = DateFormatter()
//dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
//let dateString = dateFormatter.string(from: Date())
//print(dateString)
