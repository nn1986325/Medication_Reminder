//
//  ServiceAPI.swift
//  Medtime
//
//  Created by Saranya Ravi on 26/10/23.
//

import UIKit

class ServiceAPI: Codable {
    static var ipAddress = "http://172.17.52.13/Medtime/"
    
       static var login = ipAddress+"doctor_login.php?"
       static var patientLogin = ipAddress+"user.php?"
       static var doctorProfile = ipAddress+"d_profile.php?"
       
}

