//
//  Constant.swift
//  Medtime
//
//  Created by SAIL L1 on 22/11/23.
//

import Foundation
//
//  ServiceAPI.swift
//  Medtime
class ServiceAPI: Codable {
    
       static var ipAddress = "http://172.20.10.2/Medtime/"
       static var login = ipAddress+"doctor_login.php?"
       static var patientLogin = ipAddress+"user.php?"
       static var doctorProfile = ipAddress+"d_profile.php?"
       static var doctorProfilUpadteUrl = ipAddress+"d_profileupdate.php"
       static var appoinmentUrl = ipAddress+"appprintbooked.php"
       static var addPatient = ipAddress+"addpatient.php"
       static var forgotpwd = ipAddress+"forgot_password.php"
       static var Appbooking = ipAddress+"appbooking.php"
       static var ViewPatient = ipAddress+"patientlist.php"
       static var appPendingStatus = ipAddress+"appprintbooked.php"
       static var appApprovedStatus = ipAddress+"appprintbooked1.php"
       static var appAcceptStatus = ipAddress+"appacceptance.php"
       static var patientProfileDetails = ipAddress+"patientdetails.php"
       static var addMedicine = ipAddress+"medication_reminder.php"
       static var medicationUrl = ipAddress+"medication_details.php"
       static var patientProfilUrl = ipAddress+"p_profile.php"
       static var patientProfilUpadteUrl = ipAddress+"p_profileupdate.php"
       static var patientMedication = ipAddress+"medicationhomepage.php"
       static var viewPatientSearchField = ipAddress+"search.php"
       static var appoinmentStatus = ipAddress+"appstatus.php"
       static var recentPatient = ipAddress+"patienthomelist.php"
       static var setImageUrl = ipAddress+"getimage.php"
       static var uploadImageUrl = ipAddress+"image.php"
       static var patnotifyApi = ipAddress+"patnotify.php"
       static var docnotifyGetApi = ipAddress+"docnotify.php"
}

