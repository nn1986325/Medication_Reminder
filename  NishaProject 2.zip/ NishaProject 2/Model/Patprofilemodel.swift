//
//  Patprofilemodel.swift
//  Medtime
//
//  Created by SAIL L1 on 09/12/23.
//

import Foundation

//struct Patientdetail: Codable {
//    let success: Bool
//    let data: [PatientdetailData]
//}
//
//// MARK: - Datum
//struct PatientdetailData: Codable {
//    let sNo: Int
//    let patientID, name, age, gender: String
//    let phoneNumber, treatment, bp, tsh: String
//    let rbs, fbs, ppbs, hbA1C: String
//    let attenderName, relationOfPatient, attAge, attGender: String
//    let attPhoneNumber: String
//    let image: String
//
//    enum CodingKeys: String, CodingKey {
//        case sNo = "s_no"
//        case patientID = "patient_id"
//        case name, age, gender
//        case phoneNumber = "phone_number"
//        case treatment = "Treatment"
//        case bp = "BP"
//        case tsh = "TSH"
//        case rbs = "RBS"
//        case fbs = "FBS"
//        case ppbs = "ppbs"
//        case hbA1C = "HbA1c"
//        case attenderName = "attender_name"
//        case relationOfPatient = "relation_of_patient"
//        case attAge = "att_age"
//        case attGender = "att_gender"
//        case attPhoneNumber = "att_phone_number"
//        case image
//    }
//}


struct Patientdetail: Codable {
    let success: Bool
    let data: [PatientdetailData]
}

// MARK: - Datum
struct PatientdetailData: Codable {
    let sNo: Int
    let patientID, name, age, gender: String
    let phoneNumber, treatment, bp, tsh: String
    let rbs, fbs, ppbs, hbA1C: String
    let attenderName, relationOfPatient, attAge, attGender: String
    let attPhoneNumber, image: String

    enum CodingKeys: String, CodingKey {
        case sNo = "s_no"
        case patientID = "patient_id"
        case name, age, gender
        case phoneNumber = "phone_number"
        case treatment = "Treatment"
        case bp = "BP"
        case tsh = "TSH"
        case rbs = "RBS"
        case fbs = "FBS"
        case ppbs
        case hbA1C = "HbA1c"
        case attenderName = "attender_name"
        case relationOfPatient = "relation_of_patient"
        case attAge = "att_age"
        case attGender = "att_gender"
        case attPhoneNumber = "att_phone_number"
        case image
    }
}
// MARK: - Encode/decode helpers

class JSONNull: Codable, Hashable {

    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
        return true
    }

    public var hashValue: Int {
        return 0
    }

    public init() {}

    public required init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if !container.decodeNil() {
            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encodeNil()
    }
}


//struct Patientdetail: Codable {
//    let sNo: Int
//    let patientID, name: String
//    let age: Int
//    let gender, phoneNumber, treatment: String
//    let bp, tsh, tft: Int
//    let fbs, ppbs, hbA1C, urineRoutine: String
//    let attenderName, relationOfPatient: String
//    let attAge: Int
//    let attGender, attPhoneNumber: String
//    let image:String?
//
//    enum CodingKeys: String, CodingKey {
//        case sNo = "s_no"
//        case patientID = "patient_id"
//        case name, age, gender
//        case phoneNumber = "phone_number"
//        case treatment = "Treatment"
//        case bp = "BP"
//        case tsh = "TSH"
//        case tft = "TFT"
//        case fbs = "FBS"
//        case ppbs
//        case hbA1C = "HbA1c"
//        case urineRoutine = "urine_routine"
//        case attenderName = "attender_name"
//        case relationOfPatient = "relation_of_patient"
//        case attAge = "att_age"
//        case attGender = "att_gender"
//        case attPhoneNumber = "att_phone_number"
//        case image
//
//    }
//}
//
//typealias Patientdetails = [Patientdetail]




struct NotifyValue: Codable {
    let status: String
    let data: [NotifyValueData]
}

// MARK: - Datum
struct NotifyValueData: Codable {
    let sNo: Int
    let patientID, date, medicineTaken: String

    enum CodingKeys: String, CodingKey {
        case sNo = "s_no"
        case patientID = "patient_id"
        case date
        case medicineTaken = "medicine_taken"
    }
}


struct MedicationHomepage: Codable {
    let medicationDetails: MedicationDetails

    enum CodingKeys: String, CodingKey {
        case medicationDetails = "medication_details"
    }
}

// MARK: - MedicationDetails
struct MedicationDetails: Codable {
    let firstIntake, thirdIntake, secondIntake: [Intake]

    enum CodingKeys: String, CodingKey {
        case firstIntake = "first_intake"
        case thirdIntake = "third_intake"
        case secondIntake = "second_intake"
    }
}

// MARK: - Intake
struct Intake: Codable {
    let medicationName: String
    let beforeFood, afterFood: Int
    let timing: String

    enum CodingKeys: String, CodingKey {
        case medicationName = "medication_name"
        case beforeFood = "before_food"
        case afterFood = "after_food"
        case timing = "Timing"
    }
}
