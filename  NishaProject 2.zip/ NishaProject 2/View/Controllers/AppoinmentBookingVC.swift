//
//  AppoinmentBookingVC.swift
//  Medtime
//
//  Created by SAIL L1 on 14/12/23.
//

import UIKit
import FSCalendar

class AppoinmentBookingVC: UIViewController, UITextFieldDelegate {
    
    
    
    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var subView: UIView!
    
    @IBOutlet weak var profileImage: UIImageView!
    
    
    @IBOutlet weak var makeAppoinmentBtn: UIButton!
    
    
    @IBOutlet weak var patientidField: UITextField!
    
    
    @IBOutlet weak var nameField: UITextField!
    
    
    @IBOutlet weak var isssueField: UITextField!
    
    
    @IBOutlet weak var dateTextfield: UITextField!
    
    
    
    let datePicker : UIDatePicker = UIDatePicker()
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        subView.layer.cornerRadius = 10
        dateTextfield.delegate = self
        dateTextfield.tag = 0
        
        
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
       
    }
    @IBAction func dateTextFieldBeginEditing(_ sender: UITextField) {
        showDatePicker(tag: sender.tag)
    }
    func showDatePicker(tag: Int){
        //Formate Date
        datePicker.datePickerMode = .date
        
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .inline
        }
        else {
            datePicker.preferredDatePickerStyle = .wheels
        }
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        
        //done button & cancel button
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_ :)))
        doneButton.tag = tag
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_ :)))
        cancelButton.tag = tag
        toolbar.setItems([cancelButton ,spaceButton,doneButton], animated: false)
        
        
        self.dateTextfield.inputAccessoryView = toolbar
        self.dateTextfield.inputView = datePicker
      
    }
    @objc func cancelDatePicker(_ sender: UIButton){
        self.dateTextfield.text? = ""
        self.view.endEditing(true)
    }

    @objc func donedatePicker(_ sender: UIButton){
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        self.dateTextfield.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }

    @IBAction func makeAppoinmentBtnTapped(_ sender: Any) {
        if patientidField.text != "" && nameField.text != "" && isssueField.text != "" && dateTextfield.text != "" {
            LoadingIndicator.shared.hideLoading()
        getAppointment()
        }
        else{
            DispatchQueue.main.async {
                let alertController = UIAlertController(title: "Alert", message: "Fill the empty fields", preferredStyle: .alert)

                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(cancelAction)

                self.present(alertController, animated: false, completion: nil)
            }
        }
    }
    
    func getAppointment() {
    
        let userInfo: [String: String] = [
            "patient_id": patientidField.text ?? "",
            "name": nameField.text ?? "",
            "issue": isssueField.text ?? "",
            "date": dateTextfield.text ?? ""
            ]

        APIHandler().postAPIValues(type: AppBooking.self, apiUrl: ServiceAPI.Appbooking, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            if data.status != "success" {
                                DispatchQueue.main.async {
                                    LoadingIndicator.shared.hideLoading()
                                    let alertController = UIAlertController(title: "Alert", message: data.message, preferredStyle: .alert)

                                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                    alertController.addAction(cancelAction)

                                    self.present(alertController, animated: true, completion: nil)
                                }
                            } else {
                                
                                DispatchQueue.main.async {
                                    let alertController = UIAlertController(title: "Alert", message: "Request sent Succesfully", preferredStyle: .alert)

                                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                    alertController.addAction(cancelAction)

                                    self.present(alertController, animated: true, completion: nil)
                                }
                            }

                        case .failure(let error):
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Alert", message: "\(error)", preferredStyle: .alert)

                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)

                                self.present(alertController, animated: true, completion: nil)
                            }
                        }
                    }
                }
    }



    

   
