//
//  PatientNotificationViewController.swift
//  Medtime
//
//  Created by SAIL L1 on 03/04/24.
//

import UIKit

class PatientNotificationViewController: UIViewController {
    
    
    
    @IBOutlet weak var mainView: UIView!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        mainView.backgroundColor = .black.withAlphaComponent(0.8)
    }
    

    @IBAction func yesBtnTap(_ sender: Any) {
        
        updatePatNotify(val:"Taken")
    }
    
    
    @IBAction func noBtnTap(_ sender: Any) {
        
        updatePatNotify(val:"Not taken")
    }
    
    
    
    func updatePatNotify(val:String) {
    
        let userInfo: [String: String] = [
            "patient_id": DataManager.shared.patientLoginId,
            "medicine_taken":val
           
            ]

        APIHandler().postAPIValues(type: PatNotify.self, apiUrl: ServiceAPI.patnotifyApi, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            DispatchQueue.main.async {
                                if data.status == "succes" {
                           
                                    self.dismiss(animated: false, completion: nil)
                                 
                            }else {
                                self.dismiss(animated: false, completion: nil)
//                                let alertController = UIAlertController(title: "Alert", message: "Something went wrong", preferredStyle: .alert)
//                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
//                                alertController.addAction(cancelAction)
//                                self.present(alertController, animated: true, completion: nil)
                            }
                          print(data)
                            }
                        case .failure(let error):
                            print(error)
                            self.dismiss(animated: false, completion: nil)
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Alert", message: "Error accuired", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)
                                self.present(alertController, animated: true, completion: nil)
                            }
                        }
                    }
                }
    
    
}





