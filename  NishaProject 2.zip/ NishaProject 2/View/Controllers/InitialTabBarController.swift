//
//  InitialTabBarController.swift
//  Medtime
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class InitialTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   

}
