//
//  AddPatientAttenderVc.swift
//  Meditate
//
//  Created by Saranya Ravi on 13/10/23.
//

import UIKit

class AddPatientAttenderVc: UIViewController {
    
    
    @IBOutlet weak var saveBtn: UIButton!
    
    
    
    @IBOutlet weak var attenderNameField: UITextField!
    
    @IBOutlet weak var relationShipOfPatientField: UITextField!
    
    @IBOutlet weak var ageField: UITextField!
    
    
    @IBOutlet weak var genderField: UITextField!
    
    
    @IBOutlet weak var mobileNumberField: UITextField!
    
    
    
    @IBOutlet weak var mainView: UIView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
      
        setupUI()
      
    }
    
    func setupUI() {
        
        saveBtn.layer.cornerRadius = 10
        
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
    }
    

    @IBAction func backBtnTapped(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
        
    }
    
    @IBAction func saveBtnTapped(_ sender: Any) {
        
        
        if attenderNameField.text != "" && relationShipOfPatientField.text != "" && ageField.text != "" && genderField.text != "" && mobileNumberField.text != "" {
            DispatchQueue.main.async {
                let alertController = UIAlertController(title: "Message", message: "Fill all the fields", preferredStyle: .alert)
                let cancelAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: false, completion: nil)
            }
        }else {
        
        }
        
        
    }
    
}
