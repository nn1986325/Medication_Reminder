//
//  EditDoctorViewController.swift
//  Medtime
//
//  Created by SAIL L1 on 15/02/24.
//

import UIKit

class EditDoctorViewController: UIViewController {
    
    
    @IBOutlet weak var doctorId: UITextField!
    
    @IBOutlet weak var nameField: UITextField!
    
    
    @IBOutlet weak var spealityField: UITextField!
    
    @IBOutlet weak var genderField: UITextField!
    
    
    @IBOutlet weak var mainView: UIView!
    
    var doctorIds = String()
    var name = String()
    var speality = String()
    var gender = String()
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        doctorId.text = doctorIds
        nameField.text = name
        spealityField.text = speality
        genderField.text = gender
        
        
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
    
       
    }
    
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    @IBAction func saveTap(_ sender: Any) {
        
        if nameField.text ?? "" != "" && spealityField.text ?? "" != "" && doctorId.text ?? "" != "" && genderField.text ?? "" != "" {
            LoadingIndicator.shared.showLoading(on: self.view)
            updateDoctorDetails()
        }else {
            DispatchQueue.main.async {
                let alertController = UIAlertController(title: "Message", message: "Fill all the fields", preferredStyle: .alert)
                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
            }
        }
        
       
    }
    
    
    func updateDoctorDetails() {
    
        let userInfo: [String: String] = [
            "doctor_id": DataManager.shared.doctorLoginId,
            "name": nameField.text ?? "",
            "speality": spealityField.text ?? "",
            "gender": genderField.text ?? "",
            ]

        APIHandler().postAPIValues(type: docprofile.self, apiUrl: ServiceAPI.doctorProfilUpadteUrl, method: "POST", formData: userInfo) { [self] result in
                        switch result {
                        case .success(let data):

                            DispatchQueue.main.async {
                                LoadingIndicator.shared.hideLoading()
                                let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)
                                  let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                                      self.navigationController?.popViewController(animated: false)
                                  })
                                  alertController.addAction(okAction)
                                  let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: { _ in
                                      // Handle Cancel button tap if needed
                                  })
                                  alertController.addAction(cancelAction)
                                  self.present(alertController, animated: true, completion: nil)
                              }

                        case .failure(let error):
                            LoadingIndicator.shared.hideLoading()
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Message", message: "Error accuired", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)
                                self.present(alertController, animated: true, completion: nil)
                            }
                        }
                    }
                }
    
    
   
    
    
    
    
}
