//
//  PhomeViewController.swift
//  Medtime
//
//  Created by SAIL L1 on 24/10/23.
//

import UIKit
import UserNotifications

class PhomeViewController: UIViewController, UNUserNotificationCenterDelegate {
    
    
    
   
    
    @IBOutlet weak var mainView: UIView!
    
    
    @IBOutlet weak var reninderTable: UITableView!
    
   
   
    var firstIntakeNot = [NotificationData]()
    var SecondIntakeNot = [NotificationData]()
    var ThirdIntakeNot = [NotificationData]()
    
    var patientmedication:MedicationHomepage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
 
      
        
        let cell = UINib(nibName: "MedicationReminderCell", bundle: nil)
        reninderTable.register(cell, forCellReuseIdentifier: "Cell")
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { (granted, error) in
            if granted {
                print("Notification authorization granted")
                UNUserNotificationCenter.current().delegate = self // Set delegate
            } else {
                print("Notification authorization denied")
            }
        }
        
        LoadingIndicator.shared.showLoading(on: self.view)
        getPatientMedicationAPI()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = false
    }
    
        func getPatientMedicationAPI() {
    
            let userInfo: [String: String] = [
                "patient_id": DataManager.shared.patientLoginId,
                ]
    
            APIHandler().postAPIValues(type: MedicationHomepage.self, apiUrl: ServiceAPI.patientMedication, method: "POST", formData: userInfo) { result in
                            switch result {
                            case .success(let data):
                            DispatchQueue.main.async {
                                LoadingIndicator.shared.hideLoading()
                            self.patientmedication = data
                                
                        if let firstIntake = self.patientmedication?.medicationDetails.firstIntake {
                                    for ins in firstIntake {
                                        self.firstIntakeNot.append(NotificationData(time: ins.timing, title:"Reminder!", body:"தயவுசெய்து மருந்து எடுத்துக் கொள்ளுங்கள்", identifier: ins.timing))
                                        
                                      
                                    
                                    }
                           
                                }
                                self.scheduleNotifications(notificationData: self.firstIntakeNot)

                                if let SecondIntake = self.patientmedication?.medicationDetails.secondIntake {
                                            for ins in SecondIntake {
                                                self.SecondIntakeNot.append(NotificationData(time: ins.timing, title:"Reminder!", body:"தயவுசெய்து மருந்து எடுத்துக் கொள்ளுங்கள்", identifier: ins.timing))
                                                
                                              
                                            
                                            }
                                   
                                        }
                                self.scheduleNotifications(notificationData: self.SecondIntakeNot)
                                if let ThirdIntake = self.patientmedication?.medicationDetails.thirdIntake {
                                            for ins in ThirdIntake {
                                                self.ThirdIntakeNot.append(NotificationData(time: ins.timing, title:"Reminder!", body:"தயவுசெய்து மருந்து எடுத்துக் கொள்ளுங்கள்" , identifier: ins.timing))
                                                
                                              
                                            
                                            }
                                   
                                        }
                                self.scheduleNotifications(notificationData: self.ThirdIntakeNot)
                                
                                
                                
                                
                                self.reninderTable.reloadData()
                            
                                    }
                            case .failure(let error):
                                print(error)
                                DispatchQueue.main.async {
                                    let alertController = UIAlertController(title: "Message", message: "Error accuired", preferredStyle: .alert)
                                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                    alertController.addAction(cancelAction)
                                    self.present(alertController, animated: true, completion: nil)
                                }
                            }
                        }
                    }
    
    
    
    
    @IBAction func appoinmentStatusTap(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "PatientAppoinmentStatusVC") as! PatientAppoinmentStatusVC
        navigationController?.pushViewController(vc, animated: false)
        
    }
    
  
    @IBAction func profileTap(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "PatientNotificationViewController") as! PatientNotificationViewController
        vc.modalPresentationStyle = .overCurrentContext
        self.navigationController?.present(vc, animated: false, completion: nil)
    }
    
    
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        // Customize how the notification is presented in the foreground
        completionHandler([.alert, .sound]) // Display an alert and play a sound
    }
    
    
}


    extension PhomeViewController: UITableViewDelegate,UITableViewDataSource {


        func numberOfSections(in tableView: UITableView) -> Int {
            return 3
        }
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            if section == 0 {
                return self.patientmedication?.medicationDetails.firstIntake.count ?? 0
            }else if section == 1 {
                return self.patientmedication?.medicationDetails.secondIntake.count ?? 0
            }else {
                return self.patientmedication?.medicationDetails.thirdIntake.count ?? 0
            }

        }

        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier:"Cell", for: indexPath) as! MedicationReminderCell
            if indexPath.section == 0 {
                let val = self.patientmedication?.medicationDetails.firstIntake[indexPath.row]
                cell.medicationName.text = val?.medicationName

                if val?.afterFood == 1 {
                    cell.foodIntakeLbl.text = "\(val?.timing ?? "") / After food"
                }else if val?.beforeFood == 1 {
                    cell.foodIntakeLbl.text = "\(val?.timing ?? "") / BeforeFood"
                }else {
                    cell.foodIntakeLbl.text = ""
                }

            }else if indexPath.section == 1 {
                let val = self.patientmedication?.medicationDetails.secondIntake[indexPath.row]

                cell.medicationName.text = val?.medicationName

                if val?.afterFood == 1 {
                    cell.foodIntakeLbl.text = "\(val?.timing ?? "") / After food"
                }else if val?.beforeFood == 1 {
                    cell.foodIntakeLbl.text = "\(val?.timing ?? "") / BeforeFood"
                }else {
                    cell.foodIntakeLbl.text = ""
                }
            }else {
                let val = self.patientmedication?.medicationDetails.thirdIntake[indexPath.row]

                cell.medicationName.text = val?.medicationName

                if val?.afterFood == 1 {
                    cell.foodIntakeLbl.text = "\(val?.timing ?? "") / After food"
                }else if val?.beforeFood == 1 {
                    cell.foodIntakeLbl.text = "\(val?.timing ?? "") / BeforeFood"
                }else {
                    cell.foodIntakeLbl.text = ""
                }
            }
            return cell
        }

        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 100
        }



        func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
            let headerView = UIView()
            headerView.backgroundColor = UIColor.clear

            let label = UILabel()
            label.textColor = UIColor.black
            label.font = UIFont.boldSystemFont(ofSize: 25) // Set the font size
            label.frame = CGRect(x: 16, y: 0, width: tableView.frame.width - 16, height: 30)

            if section == 0 {
                label.text =  "Morning"
            } else if section == 1 {
                label.text =  "Afternoon"
            } else {
                label.text =  "Night"
            }

            headerView.addSubview(label)

            return headerView
        }

            func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
               return 30  // Adjust the height of your header view
           }

    }



struct NotificationData {
    let time: String
    let title: String
    let body: String
    let identifier: String
}
