//
//  patientsViewController.swift
//  Meditate
//
//  Created by ahamed basith on 16/10/2023.
//

import UIKit

class patientsViewController: UIViewController, UITextFieldDelegate {
    
   
    @IBOutlet weak var addPatientCollecton: UICollectionView!
 
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var searchBarOutlet: UISearchBar! {
        didSet {
          searchBarOutlet.delegate = self
        }
    }
    var patientList : [data] = []
    var filteredPatientListData: [data] = []
    
    var patientViewList : ViewPatient?
    
    
    var patientViewSearchList : ViewPatientSearchList?
    
    var patientImage : PatientProfile?
  
    var searchOption = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        setupUi()
    }
    
    
    func setupUi() {
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        
  
       
        
        addPatientCollecton.delegate = self
        addPatientCollecton.dataSource = self
        
        let cellRecent = UINib(nibName: "AddPatientCell", bundle: nil)
        addPatientCollecton.register(cellRecent, forCellWithReuseIdentifier: "cell")
        
        
        let layout = CustomVerticalFlowLayout()
        addPatientCollecton.collectionViewLayout = layout
     
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
        LoadingIndicator.shared.showLoading(on: self.view)
        getforgotpwdAPI()
    }
    
    func getforgotpwdAPI() {
    
        searchOption = false
        APIHandler().postAPIValues(type: ViewPatient.self, apiUrl: ServiceAPI.ViewPatient, method: "POST", formData: [:]) { result in
                        switch result {
                        case .success(let data):
                            if !data.success {
                              
                            } else {
                                
                                DispatchQueue.main.async {
                                    LoadingIndicator.shared.hideLoading()
                                    self.patientViewList = data
                                    self.patientList = data.data
                                    self.filteredPatientListData = data.data
                                    self.addPatientCollecton.reloadData()
                                }
                            }

                        case .failure(let error):
                            print(error)
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Alert", message: "Something went wrong", preferredStyle: .alert)

                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)

                                self.present(alertController, animated: false, completion: nil)
                            }
                        }
                    }
            }
    
    @IBAction func backBtnTapped(_ sender: Any) {
        
    self.navigationController?.popViewController(animated: false)
        
    }
}
extension patientsViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            filteredPatientListData = patientList
        } else {
            filteredPatientListData = patientList.filter { $0.name.lowercased().contains(searchText.lowercased()) || $0.patientID.lowercased().contains(searchText.lowercased()) }
        }
        
        addPatientCollecton.reloadData()

        if filteredPatientListData.isEmpty {
            showAlert(message: "The patient doesn't exist")
        }
    }

    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)

        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)

        present(alertController, animated: true, completion: nil)
    }
}


extension patientsViewController:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        filteredPatientListData.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! AddPatientCell
            cell.nameLbl.text = filteredPatientListData[indexPath.row].name
        cell.patientId.text = filteredPatientListData[indexPath.row].patientID
        self.loadImage(url: filteredPatientListData[indexPath.row].image ?? "", imageView: cell.profileImage)
            cell.layer.cornerRadius = 15.0
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "patientdetailsViewController") as! patientdetailsViewController
        DataManager.shared.patientLoginId = filteredPatientListData[indexPath.row].patientID
        DataManager.shared.patientImage = filteredPatientListData[indexPath.row].image ?? ""
        navigationController?.pushViewController(vc, animated: false)
       }

    }



class CustomVerticalFlowLayout: UICollectionViewFlowLayout {
    override func prepare() {
        super.prepare()
        guard let collectionView = collectionView else { return }
        minimumLineSpacing = 10.0
        minimumInteritemSpacing = 10.0
        let availableWidth = collectionView.bounds.width - sectionInset.left - sectionInset.right - minimumInteritemSpacing
        let cellWidth = (availableWidth - minimumInteritemSpacing) / 2.0
        itemSize = CGSize(width: cellWidth, height: 200.0)
    }
}

