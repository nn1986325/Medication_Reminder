//
//  PprofileViewController.swift
//  Medtime
//
//  Created by SAIL L1 on 27/10/23.
//

import UIKit

class PprofileViewController: UIViewController {
    
    
    @IBOutlet weak var patientIdField: UITextField!
    
    @IBOutlet weak var nameField: UITextField!
    
    
    @IBOutlet weak var profileImage: UIImageView!
    
    
    @IBOutlet weak var saveBtn: UIButton!
    
    @IBOutlet weak var ageField: UITextField!
    
    @IBOutlet weak var subView: UIView!
    
    @IBOutlet weak var genderField: UITextField!
    
    
    @IBOutlet weak var phoneNumField: UITextField!
    
    
    
    
    
    var patientprofile:Patientprofile?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        profileImage.layer.cornerRadius = 55
        subView.clipsToBounds = true
        subView.layer.cornerRadius = 50
        subView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]

        saveBtn.layer.cornerRadius = 10
        
       
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        LoadingIndicator.shared.showLoading(on: self.view)
         getPatientDetails()
    }
    
    
    @IBAction func saveTapped(_ sender: Any) {
        
        let adminVC = self.storyboard?.instantiateViewController(identifier: "EditPatientViewController") as! EditPatientViewController
        adminVC.patientId = patientIdField.text ?? ""
        adminVC.name = nameField.text ?? ""
        adminVC.age = ageField.text ?? ""
        adminVC.gender = genderField.text ?? ""
        adminVC.number = nameField.text ?? ""
      
        self.navigationController?.pushViewController(adminVC, animated: false)
        
        
       
        
        
    }
    
    
    @IBAction func signOutTap(_ sender: Any) {
        
              DispatchQueue.main.async {
                    let alertController = UIAlertController(title: "Alert", message: "Do you want to logout?", preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
                     let adminVC = self.storyboard?.instantiateViewController(identifier: "startViewController") as! startViewController
                        if let navigationController = self.navigationController {
                            navigationController.setViewControllers([adminVC], animated: false)
                        }
                    })
                    alertController.addAction(okAction)
                    let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: { _ in
                        // Handle Cancel button tap if needed
                    })
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }

    }
    
    @IBAction func backTAp(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
    
    func getPatientDetails() {
    
        let userInfo: [String: String] = [
            "patient_id": DataManager.shared.patientLoginId,

            ]

        APIHandler().postAPIValues(type: Patientprofile.self, apiUrl: ServiceAPI.patientProfilUrl, method: "POST", formData: userInfo) { [self] result in
                        switch result {
                        case .success(let data):
                            if !data.success {
                              
                                DispatchQueue.main.async {
                                    LoadingIndicator.shared.hideLoading()
                                    let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)
                                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                    alertController.addAction(cancelAction)
                                    self.present(alertController, animated: true, completion: nil)
                                }
                            } else {
                            DispatchQueue.main.async {
                                LoadingIndicator.shared.hideLoading()
                                getImageAPI()
                                self.patientprofile = data
                                self.patientIdField.text = DataManager.shared.patientLoginId
                                self.nameField.text = self.patientprofile?.data.name
                                self.ageField.text = "\(self.patientprofile?.data.age ?? "")"
                                self.genderField.text = self.patientprofile?.data.gender
                                self.phoneNumField.text = self.patientprofile?.data.phoneNumber
                                }
                            }

                        case .failure(let error):
                            LoadingIndicator.shared.hideLoading()
                            print(error)
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Message", message: "Error accuired", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)
                                self.present(alertController, animated: true, completion: nil)
                            }
                        }
                    }
                }
     
    func getImageAPI() {
    
        let userInfo: [String: String] = [
            "patient_id": DataManager.shared.patientLoginId

            ]

        APIHandler().postAPIValues(type: PatientProfile.self, apiUrl: ServiceAPI.setImageUrl, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            DispatchQueue.main.async {
                            if data.status == "success"{
                     
                                let filteredData = data.data.filter { val in
                                    return val.patientID == DataManager.shared.patientLoginId
                                }
                                self.loadImage(url: filteredData.first?.image ?? "", imageView: self.profileImage)
                                
                            
                            }
                            }
                          print(data)
                        case .failure(let error):
                            print(error)


                        }
                    }
        }
    
    
    
    

}
