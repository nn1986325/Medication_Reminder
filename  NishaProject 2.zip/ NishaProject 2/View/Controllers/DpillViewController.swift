//
//  DpillViewController.swift
//  Meditate
//
//  Created by ahamed basith on 15/10/2023.
//

import UIKit

class DpillViewController: UIViewController {
    
    
    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var medicationTable: UITableView!
    
   

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let cell = UINib(nibName: "MedicationCell", bundle: nil)
        medicationTable.register(cell, forCellReuseIdentifier: "cell")

        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
    }
    
//    func getLoginAPI() {
//    
//        let userInfo: [String: String] = [
//            "doctor_id": usernameTxt.text ?? "",
//            "password": passwordTxt.text ?? ""
//            ]
//
//        APIHandler().postAPIValues(type: Doctorlogin.self, apiUrl: ServiceAPI.login, method: "POST", formData: userInfo) { result in
//                        switch result {
//                        case .success(let data):
//                            if !data.success {
//                                DispatchQueue.main.async {
//                                    let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)
//                                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
//                                    alertController.addAction(cancelAction)
//                                    self.present(alertController, animated: true, completion: nil)
//                                }
//                            } else {
//                               self.sendEnterPatientVc()
//                            }
//
//                        case .failure(let error):
//                            DispatchQueue.main.async {
//                                let alertController = UIAlertController(title: "Message", message: "Error accuired", preferredStyle: .alert)
//                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
//                                alertController.addAction(cancelAction)
//                                self.present(alertController, animated: true, completion: nil)
//                            }
//                        }
//                    }
//                }
//

    @IBAction func plusBtnTapped(_ sender: Any) {
        
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "pill1ViewController") as! pill1ViewController
        self.navigationController?.pushViewController(vc, animated: false)
        
        
    }
    
}
extension DpillViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"cell", for: indexPath) as! MedicationCell
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0
    }
}
