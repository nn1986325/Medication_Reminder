//
//  pill2ViewController.swift
//  Meditate
//
//  Created by SAIL on 14/10/23.
//

import UIKit

class pill2ViewController: UIViewController {
    
    
    
    @IBOutlet weak var firstTimeField: UITextField!
    
    @IBOutlet weak var secondTimeField: UITextField!
    
    @IBOutlet weak var thidrimeField: UITextField!
    
    @IBOutlet weak var mainView: UIView!
    
    
    @IBOutlet weak var beforeFoodbtn: UIButton!
    
    
    @IBOutlet weak var afterFoodBtn: UIButton!
    
    
    @IBOutlet weak var saveBtn: UIButton!
    
    
    
    
    let datePicker = UIDatePicker()
    let calendar = Calendar.current
    let currentDate = Date()
    var selectedButton: UIButton?
    
    var name = String()
    var patientId = String()
    var medicationName = String()
    var medicationForm = String()
    var morningIntake = String()
    var afterNoonIntake = String()
    var nightIntake = String()
    var foodIntake = String()
    var beforefoodTake = String()
    var afterfoodTake = String()


    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tabBarController?.tabBar.isHidden = true
        
        
        foodIntake = ""
        beforefoodTake = "no"
        afterfoodTake = "no"
        
        saveBtn.layer.cornerRadius = 10
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        datePicker.datePickerMode = .time
               
               
               self.firstTimeField.setInputViewTimePicker(target: self, selector: #selector(tapDone))
               
               
               self.secondTimeField.setInputViewTimePicker(target: self, selector: #selector(taptwoDone))
        
        
        self.thidrimeField.setInputViewTimePicker(target: self, selector: #selector(tapthreeDone))
        
    }
    @objc func tapDone() {
        if let picker = firstTimeField.inputView as? UIDatePicker {
            let dateformatter = DateFormatter()
            dateformatter.timeZone = TimeZone.current
            dateformatter.dateFormat = "hh:mm:ss"
            self.firstTimeField.text = dateformatter.string(from: picker.date)
        }
        self.firstTimeField.resignFirstResponder()
    }
    
    
    @objc func taptwoDone() {
           if let picker = secondTimeField.inputView as? UIDatePicker {
               let dateformatter = DateFormatter()
               dateformatter.timeZone = TimeZone.current
               dateformatter.dateFormat = "hh:mm:ss"
               self.secondTimeField.text = dateformatter.string(from: picker.date)
           }
           self.secondTimeField.resignFirstResponder()
       }
    
    
    @objc func tapthreeDone() {
           if let picker = thidrimeField.inputView as? UIDatePicker {
               let dateformatter = DateFormatter()
               dateformatter.timeZone = TimeZone.current
               dateformatter.dateFormat = "hh:mm:ss"
               self.thidrimeField.text = dateformatter.string(from: picker.date)
           }
           self.thidrimeField.resignFirstResponder()
       }
    
    
    
    func patientMedicineAPI() {
    
        let userInfo: [String: String] = [
            "patient_id": patientId,
            "name": name,
            "medication_name": medicationName,
            "medication_form": medicationForm,
            "morning": morningIntake,
            "afternoon": afterNoonIntake,
            "night": nightIntake,
            "before_food": beforefoodTake,
            "after_food": afterfoodTake,
            "first_intake":firstTimeField.text ?? "",
            "second_intake": secondTimeField.text ?? "",
            "third_intake": thidrimeField.text ?? ""
           
            ]

        APIHandler().postAPIValues(type: Addmedicine.self, apiUrl: ServiceAPI.addMedicine, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                          
                                DispatchQueue.main.async {
                                    LoadingIndicator.shared.hideLoading()
                                
                                    let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)

                                    let okAction = UIAlertAction(title: "OK", style: .default) { (_) in
                                        self.navigationController?.popViewController(animated: false)
                                    }

                                    let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (_) in
                                        // Add your code here to handle the Cancel button action
                                        print("Cancel button tapped")
                                    }

                                    alertController.addAction(okAction)
                                    alertController.addAction(cancelAction)

                                    self.present(alertController, animated: true, completion: nil)

                                
                            }
                        case .failure(let error):
                            DispatchQueue.main.async {
                                print(error)
                                print(error.localizedDescription)
                                let alertController = UIAlertController(title: "Message", message: "Error accuired", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)
                                self.present(alertController, animated: true, completion: nil)
                            }
                        }
                    }
                }

    
    
    
    
    @IBAction func beforeFoodTapped(_ sender: Any) {
        if selectedButton == beforeFoodbtn {
               // Deselect the button
               beforeFoodbtn.setImage(UIImage(named: "unSelectBtn"), for: .normal)
               foodIntake = ""
               beforefoodTake = "no"
               selectedButton = nil
           } else {
               // Select the button
               beforeFoodbtn.setImage(UIImage(named: "selectBtn"), for: .normal)
               foodIntake = "1"
               beforefoodTake = "yes"
               selectedButton = beforeFoodbtn

               // Deselect the other button if needed
               afterFoodBtn.setImage(UIImage(named: "unSelectBtn"), for: .normal)
           }
    }
    
    
    
    @IBAction func afterFoodTapped(_ sender: Any) {
        if selectedButton == afterFoodBtn {
                // Deselect the button
                afterFoodBtn.setImage(UIImage(named: "unSelectBtn"), for: .normal)
                foodIntake = ""
                afterfoodTake = "no"
                selectedButton = nil
            } else {
                // Select the button
                afterFoodBtn.setImage(UIImage(named: "selectBtn"), for: .normal)
                foodIntake = "1"
                afterfoodTake = "yes"
                selectedButton = afterFoodBtn

                // Deselect the other button if needed
                beforeFoodbtn.setImage(UIImage(named: "unSelectBtn"), for: .normal)
            }
    }
    
    @IBAction func saveBtnTapped(_ sender: Any) {
        
       
        if foodIntake != ""
        {
            LoadingIndicator.shared.showLoading(on: self.view)
            patientMedicineAPI()
        }
        else{
            DispatchQueue.main.async {
                LoadingIndicator.shared.showLoading(on: self.view)
                let alertController = UIAlertController(title: "Message", message: "Fill all the field", preferredStyle: .alert)
                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
            }
        }
 
        
    }
    
    
    
    @IBAction func backButtonTapped(_ sender: Any) {
        
        
        
        self.navigationController?.popViewController(animated: false)
    }
    
    
    
    
    
    
}



