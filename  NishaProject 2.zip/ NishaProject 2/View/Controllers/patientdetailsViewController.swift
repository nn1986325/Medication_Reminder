//
//  patientdetailsViewController.swift
//  Medtime
//
//  Created by SAIL L1 on 15/12/23.
//

import UIKit

class patientdetailsViewController: UIViewController {
    
    
    @IBOutlet weak var notifyTable: UITableView!
    
    @IBOutlet weak var profileImage: UIImageView!
    
    @IBOutlet weak var medicationTable: UITableView!
    
    
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var idlabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var phoneLbl: UILabel!
    @IBOutlet weak var treatmentLbl: UILabel!
    @IBOutlet weak var bpLbl: UILabel!
    @IBOutlet weak var tshLbl: UILabel!
    @IBOutlet weak var tftLbl: UILabel!
    @IBOutlet weak var fbsLbl: UILabel!
    @IBOutlet weak var ppbslbl: UILabel!
    @IBOutlet weak var hba1cLbl: UILabel!
    @IBOutlet weak var attnameLbl: UILabel!
    @IBOutlet weak var relationLbl: UILabel!
    @IBOutlet weak var ageLbl: UILabel!
    @IBOutlet weak var genderLbl: UILabel!
    @IBOutlet weak var numberLbl: UILabel!
    
    @IBOutlet weak var mainView: UIView!

    
    var patientDetails:Patientdetail?
    var medicationtDetails:Medicationdetails?
    var notifyValues:NotifyValue?
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        profileImage.layer.cornerRadius = 55
        let cell = UINib(nibName: "MedicationsCell", bundle: nil)
        medicationTable.register(cell, forCellReuseIdentifier: "Cell")
        
        let cel = UINib(nibName: "NotifyCell", bundle: nil)
        notifyTable.register(cel, forCellReuseIdentifier: "NotifyCell")
        
        notifyTable.delegate = self
        notifyTable.dataSource = self
        
        medicationTable.delegate = self
        medicationTable.dataSource = self
        
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        LoadingIndicator.shared.showLoading(on: self.view)
        getAppApprovedAPI()
       
        
    }
      

    func getAppApprovedAPI() {
    
        let userInfo: [String: String] = [
            "patient_id": DataManager.shared.patientLoginId,

            ]

        APIHandler().postAPIValues(type: Patientdetail.self, apiUrl: ServiceAPI.patientProfileDetails, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            if data.success == true {
                         DispatchQueue.main.async {
                             LoadingIndicator.shared.hideLoading()
                             self.patientDetails = data
                             LoadingIndicator.shared.showLoading(on: self.view)
                             self.getMedicationDetailAPI()
                             self.nameLbl.text = self.patientDetails?.data.first?.name
                             self.idlabel.text = self.patientDetails?.data.first?.patientID
                             self.ageLabel.text = "\(self.patientDetails?.data.first?.age ?? "")"
                             self.genderLabel.text = self.patientDetails?.data.first?.gender ?? ""
                             self.phoneLbl.text = self.patientDetails?.data.first?.phoneNumber
                             self.treatmentLbl.text = self.patientDetails?.data.first?.treatment
                             self.bpLbl.text = "\(self.patientDetails?.data.first?.bp ?? "")"
                             self.tshLbl.text = "\(self.patientDetails?.data.first?.tsh ?? "")"
                             self.tftLbl.text = "\(self.patientDetails?.data.first?.rbs ?? "")"
                             self.fbsLbl.text = self.patientDetails?.data.first?.fbs
                             self.ppbslbl.text = self.patientDetails?.data.first?.ppbs
                             self.hba1cLbl.text = self.patientDetails?.data.first?.hbA1C
                         
                             self.attnameLbl.text = self.patientDetails?.data.first?.attenderName
                             self.relationLbl.text = self.patientDetails?.data.first?.relationOfPatient
                             
                             
                             self.ageLbl.text = "\(self.patientDetails?.data.first?.attAge ?? "")"
                             self.genderLbl.text = self.patientDetails?.data.first?.attGender
                             self.numberLbl.text = self.patientDetails?.data.first?.attPhoneNumber
                             
                             self.loadImage(url:DataManager.shared.patientImage, imageView: self.profileImage)
                             
                            
                             self.getNotifyData()
                            }
                        }else {
                            
                        }
                          print(data)
                        case .failure(let error):
                            LoadingIndicator.shared.hideLoading()
                            print(error)
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Alert", message: "Something went wrong", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)
                                self.present(alertController, animated: false, completion: nil)
                            }

                        }
                    }
        }

    
    
    
    func getNotifyData() {

        let userInfo: [String: String] = [
            "patient_id": DataManager.shared.patientLoginId,

            ]

        APIHandler().postAPIValues(type: NotifyValue.self, apiUrl: ServiceAPI.docnotifyGetApi, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):

                          //  if data.status != "success"{
                         DispatchQueue.main.async {

                             self.notifyValues = data
                             self.notifyTable.reloadData()


                            }
                          print(data)
                        case .failure(let error):

                            DispatchQueue.main.async {
                             print(error)
                            }

                        }
                    }
        }
    
    
    func getMedicationDetailAPI() {
    
        let userInfo: [String: String] = [
            "patient_id": DataManager.shared.patientLoginId

            ]

        APIHandler().postAPIValues(type: Medicationdetails.self, apiUrl: ServiceAPI.medicationUrl, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            
                          //  if data.status != "success"{
                         DispatchQueue.main.async {
                             LoadingIndicator.shared.hideLoading()
                             self.medicationtDetails = data
                             self.medicationTable.reloadData()
                          //   self.getNotifyData()
                            }
                          print(data)
                        case .failure(let error):
                            LoadingIndicator.shared.hideLoading()
                            print(error)

                        }
                    }
        }
    
    
//    func getImageAPI() {
//
//        let userInfo: [String: String] = [
//            "patient_id": DataManager.shared.patientLoginId
//
//            ]
//
//        APIHandler().postAPIValues(type: PatientProfile.self, apiUrl: ServiceAPI.setImageUrl, method: "POST", formData: userInfo) { result in
//                        switch result {
//                        case .success(let data):
//                            DispatchQueue.main.async {
//                            if data.status == "success"{
//
//                                let filteredData = data.data.filter { val in
//                                    return val.patientID == DataManager.shared.patientLoginId
//                                }
//
//
//                            }
//                            }
//                          print(data)
//                        case .failure(let error):
//                            print(error)
////                            DispatchQueue.main.async {
////                                let alertController = UIAlertController(title: "Alert", message: "Something went wrong", preferredStyle: .alert)
////                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
////                                alertController.addAction(cancelAction)
////                                self.present(alertController, animated: false, completion: nil)
////                            }
//
//                        }
//                    }
//        }
    
    
    
    @IBAction func backTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
  

}
extension patientdetailsViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == notifyTable {
            return self.notifyValues?.data.count ?? 0
        }else {
            
            return self.medicationtDetails?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      
        if tableView == notifyTable {
   
            let cel = tableView.dequeueReusableCell(withIdentifier: "NotifyCell", for: indexPath) as! NotifyCell
            let val = self.notifyValues?.data[indexPath.row]
            cel.medicineTakenDate.text = val?.date
            cel.takenLbl.text = val?.medicineTaken
            return cel
        }else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! MedicationsCell
            cell.tabletName.text = medicationtDetails?[indexPath.row].medicationName
            cell.intakeLbl.text = "\(medicationtDetails?[indexPath.row].morning ?? 0) - \(medicationtDetails?[indexPath.row].afternoon ?? 0) - \(medicationtDetails?[indexPath.row].night ?? 0)"
           return cell
           
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == notifyTable {
            return 50.0
        }else {
            return 75.0
        }
    }
    
}




