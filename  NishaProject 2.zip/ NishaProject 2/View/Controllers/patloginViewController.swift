//
//  patloginViewController.swift
//  Medtime
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class patloginViewController: UIViewController {


    @IBOutlet weak var forgotpwdtxt: UIButton!
    
    @IBOutlet weak var passWordField: UITextField!
 
    @IBOutlet weak var pusernametxt: UITextField!
    
    
    @IBOutlet weak var mainView: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        passWordField.isSecureTextEntry = true
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
    }
    

    @IBAction func loginbtn(_ sender: Any) {
      
        getPatientLoginAPI()
    }
    
    
    @IBAction func Pfrgtbtn(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "PforgetpwdViewController") as! PforgetpwdViewController
        
        navigationController?.pushViewController(vc, animated: false)
        
    }
    
    
    
    @IBAction func bacBtnTapped(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
    
    
    @IBAction func showPassTapped(_ sender: Any) {
        
        
        if passWordField.isSecureTextEntry == false {
            passWordField.isSecureTextEntry = true
        }else {
            passWordField.isSecureTextEntry = false
        }
    }
    
    func getPatientLoginAPI() {
    
        let userInfo: [String: String] = [
            "patient_id": pusernametxt.text ?? "",
            "password": passWordField.text ?? ""
            ]

        APIHandler().postAPIValues(type: Doctorlogin.self, apiUrl: ServiceAPI.patientLogin, method: "POST", formData: userInfo) { [self] result in
                        switch result {
                        case .success(let data):
                            if !data.success {
                                
                              
                                
                                DispatchQueue.main.async {[self] in
                                    LoadingIndicator.shared.hideLoading()
                                    let alertController = UIAlertController(title: "Alert", message: data.message, preferredStyle: .alert)

                                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                    alertController.addAction(cancelAction)

                                    self.present(alertController, animated: true, completion: nil)
                                }
                            } else {
                           
                            self.sendEnterPatientVc()
                            }

                        case .failure(let error):
                            LoadingIndicator.shared.hideLoading()
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Alert", message: "Something went wrong", preferredStyle: .alert)

                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)

                                self.present(alertController, animated: true, completion: nil)
                            }
                        }
                    }
                }
    
    
    
    func sendEnterPatientVc() {
        DispatchQueue.main.async {
            DataManager.shared.patientLoginId = self.pusernametxt.text ?? ""
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "PatientTabBarController") as! PatientTabBarController
                
                self.navigationController?.pushViewController(vc, animated: false)
        }
       
    }

}
