//
//  PatientAppoinmentStatusVC.swift
//  Medtime
//
//  Created by SAIL L1 on 22/12/23.
//

import UIKit

class PatientAppoinmentStatusVC: UIViewController {
    
    
    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var tableView: UITableView!
    
    
    var approvedStatus:Status?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 50
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        
        let cell = UINib(nibName: "PatientRecordTableViewCell", bundle: nil)
        self.tableView.register(cell, forCellReuseIdentifier: "cell")
        LoadingIndicator.shared.showLoading(on: self.view)
        getAppointment()
    }
    

    @IBAction func backTapped(_ sender: Any) {
        
        
        self.navigationController?.popViewController(animated: false)
    }
    
    
    func getAppointment() {
    
        let userInfo: [String: String] = [
            "patient_id": DataManager.shared.patientLoginId
          
            ]

        APIHandler().postAPIValues(type: Status.self, apiUrl: ServiceAPI.appoinmentStatus, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            DispatchQueue.main.async {
                                LoadingIndicator.shared.hideLoading()
                                self.approvedStatus = data
                                self.tableView.reloadData()
                                   
                                }
                           

                        case .failure(_):
                            LoadingIndicator.shared.hideLoading()
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Alert", message: "Something went wrong", preferredStyle: .alert)

                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)

                                self.present(alertController, animated: true, completion: nil)
                            }
                        }
                    }
                }
    

}
extension PatientAppoinmentStatusVC: UITableViewDelegate,UITableViewDataSource {
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return approvedStatus?.data.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! PatientRecordTableViewCell
        let val = approvedStatus?.data[indexPath.row]
        cell.patientId.text = val?.patientID
        cell.patientName.text = val?.name
        cell.patientIssues.text = val?.issue
        cell.date.text = val?.date
        cell.acceptBtn.setTitle("Approved", for: .normal)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180.0
    }
    
}
