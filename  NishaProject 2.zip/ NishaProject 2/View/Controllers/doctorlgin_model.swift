//
//  doctorlgin_model.swift
//  Medtime
//
//  Created by SAIL L1 on 21/11/23.
//

import Foundation
struct Doctorlogin: Codable {
    let success: Bool
    let message: String
}


struct AppBooking: Codable {
    let status: String
    let message: String
}



struct WelcomeElement: Codable {
   let sNo: Int
   let patientID, name, issue, date: String
   let status: String

   enum CodingKeys: String, CodingKey {
       case sNo = "s_no"
       case patientID = "patient_id"
       case name, issue, date, status
   }
}


struct Addpatient: Codable {
    let userPasswordUpdated, userInserted, patientdetails_inserted, addpatientInserted: Bool
    let pProfileInserted: Bool

    enum CodingKeys: String, CodingKey {
        case userPasswordUpdated = "user_password_updated"
        case userInserted = "user_inserted"
        case patientdetails_inserted
        case addpatientInserted = "addpatient_inserted"
        case pProfileInserted = "p_profile_inserted"
       
    }
}

struct forgotpwd: Codable {
    let success: Bool
    let message: String
}




struct ViewPatientSearchList: Codable {
    let patientID, name: String
    let image: String?

    enum CodingKeys: String, CodingKey {
        case patientID = "patient_id"
        case name
        case image
    }
}



struct ViewPatient: Codable {
    let success: Bool
    let data: [data]
}
struct data: Codable {
    let patientID, name: String
    let image:String?

    enum CodingKeys: String, CodingKey {
        case patientID = "patient_id"
        case name
        case image
    }
}

struct Addmedicine: Codable {
    let message: String
}



struct DocProfile: Codable {
    let success: Bool
    let data: DocProfileDataClass
    let message: String
}

struct DocProfileDataClass: Codable {
    let sNo: Int
    let doctorID, doctorName, speciality, gender: String

    enum CodingKeys: String, CodingKey {
        case sNo = "s_no"
        case doctorID = "doctor_id"
        case doctorName = "doctor_name"
        case speciality, gender
    }
}
