//
//  PforgetpwdViewController.swift
//  Meditate
//
//  Created by ahamed basith on 15/10/2023.
//

import UIKit

class PforgetpwdViewController: UIViewController {
    
    
    @IBOutlet weak var subView: UIView!
   // @IBOutlet weak var nameView: UIView!
    @IBOutlet weak var patientView: UIView!
  //  @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var newPassView: UIView!
   // @IBOutlet weak var reEnterPassView: UIView!
    
    @IBOutlet weak var id: UITextField!
    
    @IBOutlet weak var newPwd: UITextField!
    
    @IBOutlet weak var confirmPwd: UITextField!
    

    
    @IBOutlet weak var resetPassBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }
    
    func  setupUI() {
        
        subView.clipsToBounds = true
        subView.layer.cornerRadius = 50
        subView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
      
        resetPassBtn.layer.cornerRadius = resetPassBtn.frame.height / 2
     
//        nameView.layer.shadowOffset = CGSize(width: 0, height: 3)
//        nameView.layer.shadowOpacity = 0.6
//        nameView.layer.shadowRadius = 3.0
//        nameView.layer.cornerRadius = 10

//        patientView.layer.shadowOffset = CGSize(width: 0, height: 3)
//        patientView.layer.shadowOpacity = 0.6
//        patientView.layer.shadowRadius = 3.0
//        patientView.layer.cornerRadius = 10
        
//        emailView.layer.shadowOffset = CGSize(width: 0, height: 3)
//        emailView.layer.shadowOpacity = 0.6
//        emailView.layer.shadowRadius = 3.0
//        emailView.layer.cornerRadius = 10
        
//        newPassView.layer.shadowOffset = CGSize(width: 0, height: 3)
//        newPassView.layer.shadowOpacity = 0.6
//        newPassView.layer.shadowRadius = 3.0
//        newPassView.layer.cornerRadius = 10

//        reEnterPassView.layer.shadowOffset = CGSize(width: 0, height: 3)
//        reEnterPassView.layer.shadowOpacity = 0.6
//        reEnterPassView.layer.shadowRadius = 3.0
//        reEnterPassView.layer.cornerRadius = 10
      
    }
    
  
    
    
    
    

    @IBAction func resetbtn(_ sender: Any) {
        
            if id.text ?? "" != "" && newPwd.text ?? "" != "" && confirmPwd.text ?? "" != "" {
                if newPwd.text ?? "" == confirmPwd.text ?? "" {
                    LoadingIndicator.shared.showLoading(on: self.view)
                    getforgotpwdAPI()
                }else {
                    DispatchQueue.main.async {
                        let alertController = UIAlertController(title: "Alert", message: "fill all the fileds", preferredStyle: .alert)

                        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                        alertController.addAction(cancelAction)

                        self.present(alertController, animated: true, completion: nil)
                    }
                }
               
            } else {
                DispatchQueue.main.async {
                    let alertController = UIAlertController(title: "Alert", message: "fill all the fileds", preferredStyle: .alert)

                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(cancelAction)

                    self.present(alertController, animated: true, completion: nil)
                }
            }
              
    }
    
    
    @IBAction func backBtnTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    
    
    func getforgotpwdAPI() {
      
    
        let userInfo: [String: String] = [
            "patient_id": id.text ?? "",
            "new_password": newPwd.text ?? "",
            "confirm_password": confirmPwd.text ?? ""
            ]

        APIHandler().postAPIValues(type: forgotpwd.self, apiUrl: ServiceAPI.forgotpwd, method: "POST", formData: userInfo) { result in
                        switch result {
                        case .success(let data):
                            if !data.success {
                                DispatchQueue.main.async {
                                    let alertController = UIAlertController(title: "Alert", message: data.message, preferredStyle: .alert)

                                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                    alertController.addAction(cancelAction)

                                    self.present(alertController, animated: true, completion: nil)
                                }
                            } else {
                                
                                DispatchQueue.main.async {
                                      let alertController = UIAlertController(title: "Alert", message: "Password changed succesfully", preferredStyle: .alert)
                                      let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                                          self.navigationController?.popViewController(animated: false)
                                      })
                                      alertController.addAction(okAction)
//
                                      
                                      self.present(alertController, animated: true, completion: nil)
                                  }
                            }

                        case .failure(let error):
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Alert", message: "\(error)", preferredStyle: .alert)

                                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                alertController.addAction(cancelAction)

                                self.present(alertController, animated: true, completion: nil)
                            }
                        }
                    }
                }
    
    
    
   
       
    }



    
    
   

