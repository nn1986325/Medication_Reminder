//
//  startViewController.swift
//  Medtime
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class startViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()


      
    }
    
    @IBAction func startAction(_ sender: Any)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "adminViewController") as! adminViewController
        navigationController?.pushViewController(vc, animated: false)
    }
    
    

}
