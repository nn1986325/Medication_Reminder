//
//  DforgetpwdViewController.swift
//  Meditate
//
//  Created by ahamed basith on 15/10/2023.
//

import UIKit

class DforgetpwdViewController: UIViewController {
    
    
    @IBOutlet weak var subView: UIView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        subView.clipsToBounds = true
        subView.layer.cornerRadius = 50
        subView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
    }
    

    @IBAction func resetbtn(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "DloginViewController") as! DloginViewController
        
        navigationController?.pushViewController(vc, animated: false)
    }

}
