//
//  PatientTabBarController.swift
//  Medtime
//
//  Created by SAIL L1 on 14/12/23.
//

import UIKit

class PatientTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

       print("fsdf")
    }
    


}
