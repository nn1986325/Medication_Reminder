//
//  HomeTabBarController.swift
//  Medtime
//
//  Created by SAIL L1 on 11/12/23.
//

import UIKit

class HomeTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    

   

}
