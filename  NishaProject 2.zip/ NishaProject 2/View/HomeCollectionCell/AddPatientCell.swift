//
//  AddPatientCell.swift
//  Medtime
//
//  Created by SAIL L1 on 16/11/23.
//

import UIKit

class AddPatientCell: UICollectionViewCell {
    
    
    
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var patientId: UILabel!
    
    
    @IBOutlet weak var nameLbl: UILabel!
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        profileImage.layer.cornerRadius = 55
    }

}
