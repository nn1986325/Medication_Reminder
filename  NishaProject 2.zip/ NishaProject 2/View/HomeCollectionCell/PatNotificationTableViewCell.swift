//
//  PatNotificationTableViewCell.swift
//  Medtime
//
//  Created by SAIL L1 on 03/04/24.
//

import UIKit

class PatNotificationTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
