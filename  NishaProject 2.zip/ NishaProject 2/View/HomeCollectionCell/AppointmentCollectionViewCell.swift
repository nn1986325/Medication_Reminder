//
//  AppointmentCollectionViewCell.swift
//  Medtime
//
//  Created by SAIL on 09/11/23.
//

import UIKit

class AppointmentCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var profileView: UIView!
    
    @IBOutlet weak var acceptBtn: UIButton!
    
    
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var reasonlbl: UILabel!
    @IBOutlet weak var idLbl: UILabel!
    @IBOutlet weak var pendinglbl: UILabel!
    
    @IBOutlet weak var nameLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        profileView.layer.cornerRadius = 10
        
        acceptBtn.layer.cornerRadius = 8
    }

}
