//
//  RecentPatientCell.swift
//  Medtime
//
//  Created by SAIL on 09/11/23.
//

import UIKit

class RecentPatientCell: UICollectionViewCell {
    
    
    @IBOutlet weak var recentPatientTable: UITableView!
    
    @IBOutlet weak var seeAllButton: UIButton!
    
    
    var addPatient:(() ->())?
    
    var addRecentPatient:(() ->())?
    
    var patients:[RecentPatientData]?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        setupUI()
    }
   
    func tableReload(value:[RecentPatientData]) {
        patients = value
        self.recentPatientTable.reloadData()
    }
    
    func setupUI() {
        
        recentPatientTable.delegate = self
        recentPatientTable.dataSource = self
        
        let cell = UINib(nibName: "RecentPatientTableCell", bundle: nil)
        recentPatientTable.register(cell, forCellReuseIdentifier: "recentPatientTableCell")
       
       
    }

}
extension RecentPatientCell: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return patients?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "recentPatientTableCell", for: indexPath) as! RecentPatientTableCell
        cell.patient_Id.text = patients?[indexPath.row].patientID
        cell.selectRecentPatient = {
            self.addRecentPatient?()
        }

        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70.0
    }


}
