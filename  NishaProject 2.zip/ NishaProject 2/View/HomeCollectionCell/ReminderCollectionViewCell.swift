//
//  ReminderCollectionViewCell.swift
//  Medtime
//
//  Created by SAIL on 09/11/23.
//

import UIKit

class ReminderCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var reminderView: UIView!
    
    @IBOutlet weak var reminderCollection: UICollectionView!
    

    let imageArray = ["imageOne", "med1", "med2"]
    var timer: Timer?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        reminderCollection.delegate = self
        reminderCollection.dataSource = self
  
        let cellRecent = UINib(nibName: "ReminderImageCell", bundle: nil)
        reminderCollection.register(cellRecent, forCellWithReuseIdentifier: "cell")
        
        reminderView.clipsToBounds = true
        reminderView.layer.cornerRadius = 20
        reminderView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
      
          timer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(scrollToNextItem), userInfo: nil, repeats: true)
        
      }
          deinit {
                 stopAutoScroll()
             }

             func startAutoScroll() {
                 timer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(scrollToNextItem), userInfo: nil, repeats: true)
             }

             func stopAutoScroll() {
                 timer?.invalidate()
             }

             @objc func scrollToNextItem() {
                 guard let visibleIndexPath = reminderCollection.indexPathsForVisibleItems.first else {
                     return
                 }

                 let nextIndexPath: IndexPath
                 if visibleIndexPath.item + 1 < imageArray.count {
                     nextIndexPath = IndexPath(item: visibleIndexPath.item + 1, section: visibleIndexPath.section)
                 } else {
                     // If we are at the last item, scroll back to the first item
                     nextIndexPath = IndexPath(item: 0, section: visibleIndexPath.section)
                 }

                 reminderCollection.scrollToItem(at: nextIndexPath, at: .centeredHorizontally, animated: true)
             }
    
//        timer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(scrollToNextItem), userInfo: nil, repeats: true)
  //  }
    
    

//    deinit {
//        timer?.invalidate()
//    }

//    @objc func scrollToNextItem() {
//
//        guard let visibleIndexPath = reminderCollection.indexPathsForVisibleItems.first else {
//            return
//        }
//
//        let nextIndexPath: IndexPath
//        if visibleIndexPath.item + 1 < imageArray.count {
//            nextIndexPath = IndexPath(item: visibleIndexPath.item + 1, section: visibleIndexPath.section)
//        } else {
//
//            timer?.invalidate()
//            return
//        }
//       reminderCollection.scrollToItem(at: nextIndexPath, at: .centeredHorizontally, animated: true)
//    }

}
extension ReminderCollectionViewCell: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ReminderImageCell
        let imageName = imageArray[indexPath.item]
        cell.bannerImagew.image = UIImage(named: imageName)
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 200.0)
    }
    
}
