<?php
// Include database connection
require("dbh.php");

// Initialize response array
$response = array();

// Check if the required parameters are set in the POST request
if (isset($_POST["patient_id"]) && isset($_POST["medicine_taken"])) {
    // Assign POST values to variables
    $patient_id = $_POST["patient_id"];
    $medicine_taken = $_POST["medicine_taken"];

    try {
        // Get the current date
        $current_date = date("Y-m-d");

        // Check if a record exists for the current date and patient ID combination
        $check_sql = "SELECT * FROM notification WHERE patient_id = :patient_id AND date = :date";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bindParam(':patient_id', $patient_id);
        $check_stmt->bindParam(':date', $current_date);
        $check_stmt->execute();

        // If no record exists, insert a new record
        if ($check_stmt->rowCount() == 0) {
            // Prepare SQL statement to insert data into the notification table
            $insert_sql = "INSERT INTO notification (patient_id, date, medicine_taken) VALUES (:patient_id, :date, :medicine_taken)";
            $insert_stmt = $conn->prepare($insert_sql);
            $insert_stmt->bindParam(':patient_id', $patient_id);
            $insert_stmt->bindParam(':date', $current_date);
            $insert_stmt->bindParam(':medicine_taken', $medicine_taken);

            if ($insert_stmt->execute()) {
                $response['status'] = 'success';
                $response['message'] = 'Data inserted successfully for the current date.';
            } else {
                $response['status'] = 'error';
                $response['message'] = 'Failed to insert data for the current date.';
            }
        } else {
            // If a record already exists for the current date and patient ID combination, return error
            $response['status'] = 'error';
            $response['message'] = 'A record already exists for the current date and patient ID combination.';
        }
    } catch (PDOException $e) {
        // Handle any PDO exceptions
        $response['status'] = 'error';
        $response['message'] = 'PDO Exception: ' . $e->getMessage();
    }
} else {
    // Error response for missing parameters in the POST request
    $response['status'] = 'error';
    $response['message'] = 'Required parameters (patient_id, medicine_taken) are missing in the POST request.';
}

// Convert response array to JSON and output
header('Content-Type: application/json');
echo json_encode($response);
?>
