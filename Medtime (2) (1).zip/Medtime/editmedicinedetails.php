<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json'); // Set the header for JSON response

    $response = array(); // Initialize an empty array for the JSON response

    // Fetch the medication data directly from POST parameters
    $patient_id = $_POST['patient_id'] ?? null;
    $name = $_POST['name'] ?? null;
    $medication_name = $_POST['medication_name'] ?? null;  
    $medication_form = $_POST['medication_form'] ?? null;
    $morning = $_POST['morning'] ?? null;
    $afternoon = $_POST['afternoon'] ?? null;
    $night = $_POST['night'] ?? null;
    $before_food = $_POST['before_food'] ?? null;
    $after_food = $_POST['after_food'] ?? null;
    $first_intake = $_POST['first_intake'] ?? null;
    $second_intake = $_POST['second_intake'] ?? null;
    $third_intake = $_POST['third_intake'] ?? null;

    try {
        require 'dbh.php'; // Database connection

        // Prepare the SQL query for updating the existing medication record
        // Convert 'yes' or 'no' to 1 or 0
        $morningValue = ($morning === 'yes') ? 1 : 0;
        $afternoonValue = ($afternoon === 'yes') ? 1 : 0;
        $beforeFood = ($before_food === 'yes') ? 1 : 0;  
        $afterFood = ($after_food === 'yes') ? 1 : 0;
        $nightValue = ($night === 'yes') ? 1 : 0;

        // Set intake times to 0 based on 'no' values for morning, afternoon, night
        $firstIntake = ($morningValue === 0) ? '0' : $first_intake;
        $secondIntake = ($afternoonValue === 0) ? '0' : $second_intake;
        $thirdIntake = ($nightValue === 0) ? '0' : $third_intake;

        $updateQuery = "UPDATE medication SET 
                        name = :name,
                        medication_name = :medication_name,
                        medication_form = :medication_form,
                        morning = :morning,
                        afternoon = :afternoon,
                        night = :night,
                        before_food = :before_food,
                        after_food = :after_food,
                        first_intake = :first_intake,
                        second_intake = :second_intake,
                        third_intake = :third_intake
                        WHERE patient_id = :patient_id";
        $updateStmt = $conn->prepare($updateQuery);

        // Bind parameters and execute update
        $updateStmt->bindParam(':patient_id', $patient_id);
        $updateStmt->bindParam(':name', $name);
        $updateStmt->bindParam(':medication_name', $medication_name);
        $updateStmt->bindParam(':medication_form', $medication_form);
        $updateStmt->bindParam(':morning', $morningValue);
        $updateStmt->bindParam(':afternoon', $afternoonValue);
        $updateStmt->bindParam(':night', $nightValue);
        $updateStmt->bindParam(':before_food', $beforeFood);
        $updateStmt->bindParam(':after_food', $afterFood);
        $updateStmt->bindParam(':first_intake', $firstIntake);
        $updateStmt->bindParam(':second_intake', $secondIntake);
        $updateStmt->bindParam(':third_intake', $thirdIntake);

        // Execute the update
        $updateStmt->execute();

        // Check if any rows were affected by the update
        $rowCount = $updateStmt->rowCount();
        if ($rowCount > 0) {
            $response['message'] = "Medication record updated successfully";
        } else {
            $response['error'] = "No medication record found for the specified patient_id";
        }

    } catch (PDOException $e) {
        $response['error'] = "Error: " . $e->getMessage();
    }

    // Close the database connection
    $conn = null;

    echo json_encode($response); // Convert the response array to JSON and echo it
} else {
    echo json_encode(array('error' => 'Invalid request method. Please use POST.'));
}
?>
