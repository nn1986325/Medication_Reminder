<?php
require_once "dbh.php";
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the 'patient_id' is set in the POST request
    if(isset($_POST['patient_id'])) {
        try {
            // Sanitize the input to prevent SQL injection
            $patientId = $_POST['patient_id'];
            $query = "SELECT addpatient.patient_id, addpatient.name, image.image 
                      FROM addpatient 
                      LEFT JOIN image ON addpatient.patient_id = image.patient_id
                      WHERE addpatient.patient_id = :patient_id";
            
            // Prepare the SQL query
            $stmt = $conn->prepare($query);
            
            // Bind the parameter and execute the query
            $stmt->bindParam(':patient_id', $patientId);
            $stmt->execute();
            
            $patient = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($patient) {
                // Convert the fetched patient data to JSON format
                echo json_encode($patient);
            } else {
                echo json_encode(array('error' => 'Patient not found'));
            }
        } catch (PDOException $e) {
            // Handle any potential errors here
            echo json_encode(array('error' => 'Database error: ' . $e->getMessage()));
        }
    } else {
        echo json_encode(array('error' => 'No patient_id provided'));
    }
}
?>
