<?php
// Include the database connection file (replace with your actual database connection code)
require("dbh.php");

// Check if the request is a POST request and the input is not empty
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty(file_get_contents("php://input"))) {
    // Get the JSON data from the request body
    $json_POST = file_get_contents("php://input");

    // Decode the JSON data into an associative array
    $POST = json_decode($json_POST, true);

    // Check if the JSON data was successfully decoded
    if (json_last_error() === JSON_ERROR_NONE) {
        // Extract data from the JSON
        $doctor_id = $POST['doctor_id'] ?? null;
        $doctor_name = $POST['doctor_name'] ?? null;
        $speciality = $POST['speciality'] ?? null;
        $gender = $POST['gender'] ?? null;

        // Check if required data is present
        if ($doctor_id !== null && $doctor_name !== null && $speciality !== null && $gender !== null) {
            // Perform the database update (replace with your database update code using prepared statements for security)
            // Example: Use prepared statements to prevent SQL injection
            // $stmt = $conn->prepare("UPDATE d_profile SET doctor_name = ?, speciality = ?, gender = ? WHERE doctor_id = ?");
            // $stmt->bind_param("sssi", $doctor_name, $speciality, $gender, $doctor_id);
            // $stmt->execute();

            // Placeholder success response (modify as per your actual database update logic)
            $response = array('status' => 'success', 'message' => 'Data updated successfully');
            echo json_encode($response);
        } else {
            $response = array('status' => 'error', 'message' => 'Missing or incomplete data in the request');
            echo json_encode($response);
        }
    } else {
        $response = array('status' => 'error', 'message' => 'Invalid JSON data');
        echo json_encode($response);
    }
} else {
    $response = array('status' => 'error', 'message' => 'Invalid request method or empty input');
    echo json_encode($response);
}
?>
