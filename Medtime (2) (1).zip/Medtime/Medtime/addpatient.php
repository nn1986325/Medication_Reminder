<?php
// Include database connection
include("dbh.php");

$response = array(); // Initialize an array to hold the response data

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you receive the necessary parameters in the POST request
    // Adjust these as per your form or JSON payload
    $patient_id = $_POST['patient_id'];
    $name = $_POST['name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $phone_number = $_POST['phone_number'];
    $Treatment = $_POST['Treatment'];
    $BP = $_POST['BP'];
    $TSH = $_POST['TSH'];
    $TFT = $_POST['TFT'];
    $FBS = $_POST['FBS'];
    $ppbs = $_POST['ppbs'];
    $HbA1c = $_POST['HbA1c'];
    $urine_routine = $_POST['urine_routine'];
    $attender_name = $_POST['attender_name'];
    $relation_of_patient = $_POST['relation_of_patient'];
    $att_age = $_POST['att_age'];
    $att_gender = $_POST['att_gender'];
    $att_phone_number = $_POST['att_phone_number'];

    try {
        // Update user table with the last four digits of patient_id as password
        $password = substr($patient_id, -4);
        $sqlUpdateUser = "UPDATE user SET password = :password WHERE patient_id = :patient_id";
        $userUpdateStmt = $conn->prepare($sqlUpdateUser);
        $userUpdateStmt->bindParam(':password', $password);
        $userUpdateStmt->bindParam(':patient_id', $patient_id);
        if ($userUpdateStmt->execute()) {
            $response['user_password_updated'] = true;
        } else {
            $response['user_password_updated'] = false;
            $response['error_updating_user_password'] = $userUpdateStmt->errorInfo();
        }

        // Insert into user table
        $sqlInsertUser = "INSERT INTO user (patient_id, password) VALUES (:patient_id, :password)";
        $userStmt = $conn->prepare($sqlInsertUser);
        $userStmt->bindParam(':patient_id', $patient_id);
        $userStmt->bindParam(':password', $password);
        if ($userStmt->execute()) {
            $response['user_inserted'] = true;
        } else {
            $response['user_inserted'] = false;
        $response['error_inserting_user'] = $userStmt->errorInfo();
    }


        // Insert into patientdetails table
        $sqlInsertPatientDetails = "
        INSERT INTO patientdetails (patient_id, name, age, gender, phone_number, Treatment, BP, TSH, TFT, FBS, ppbs, HbA1c, urine_routine,attender_name, relation_of_patient, att_age, att_gender, att_phone_number)
        VALUES (:patient_id, :name, :age, :gender, :phone_number, :Treatment, :BP, :TSH, :TFT, :FBS, :ppbs, :HbA1c, :urine_routine, :attender_name, :relation_of_patient, :att_age, :att_gender, :att_phone_number)
        ";
        $patientDetailsStmt = $conn->prepare($sqlInsertPatientDetails);
        $patientDetailsStmt->bindParam(':patient_id', $patient_id);
        $patientDetailsStmt->bindParam(':name', $name);
        $patientDetailsStmt->bindParam(':age', $age);
        $patientDetailsStmt->bindParam(':gender', $gender);
        $patientDetailsStmt->bindParam(':phone_number', $phone_number);
        $patientDetailsStmt->bindParam(':Treatment', $Treatment);
        $patientDetailsStmt->bindParam(':BP', $BP);
        $patientDetailsStmt->bindParam(':TSH', $TSH);
        $patientDetailsStmt->bindParam(':TFT', $TFT);
        $patientDetailsStmt->bindParam(':FBS', $FBS);
        $patientDetailsStmt->bindParam(':ppbs', $ppbs);
        $patientDetailsStmt->bindParam(':HbA1c', $HbA1c);
        $patientDetailsStmt->bindParam(':urine_routine', $urine_routine);
        $patientDetailsStmt->bindParam(':attender_name', $attender_name);
        $patientDetailsStmt->bindParam(':relation_of_patient', $relation_of_patient);
        $patientDetailsStmt->bindParam(':att_age', $att_age);
        $patientDetailsStmt->bindParam(':att_gender', $att_gender);
        $patientDetailsStmt->bindParam(':att_phone_number', $att_phone_number);
        

        if ($patientDetailsStmt->execute()) {
            $response['patientdetails_inserted'] = true;
        } else {
            $response['patientdetails_inserted'] = false;
            $response['error_inserting_patientdetails'] = $patientDetailsStmt->errorInfo();
        }

        // Insert into addpatient table
        $sqlInsertAddPatient = "
        INSERT INTO addpatient (patient_id, name, age, gender, phone_number, Treatment, BP, TSH, TFT, FBS, ppbs, HbA1c, urine_routine,attender_name, relation_of_patient, att_age, att_gender, att_phone_number)
        VALUES (:patient_id, :name, :age, :gender, :phone_number, :Treatment, :BP, :TSH, :TFT, :FBS, :ppbs, :HbA1c, :urine_routine, :attender_name, :relation_of_patient, :att_age, :att_gender, :att_phone_number)
        ";
        $addPatientStmt = $conn->prepare($sqlInsertAddPatient);
        $addPatientStmt->bindParam(':patient_id', $patient_id);
        $addPatientStmt->bindParam(':name', $name);
        $addPatientStmt->bindParam(':age', $age);
        $addPatientStmt->bindParam(':gender', $gender);
        $addPatientStmt->bindParam(':phone_number', $phone_number);
        $addPatientStmt->bindParam(':Treatment', $Treatment);
        $addPatientStmt->bindParam(':BP', $BP);
        $addPatientStmt->bindParam(':TSH', $TSH);
        $addPatientStmt->bindParam(':TFT', $TFT);
        $addPatientStmt->bindParam(':FBS', $FBS);
        $addPatientStmt->bindParam(':ppbs', $ppbs);
        $addPatientStmt->bindParam(':HbA1c', $HbA1c);
        $addPatientStmt->bindParam(':urine_routine', $urine_routine);
        $addPatientStmt->bindParam(':attender_name', $attender_name);
        $addPatientStmt->bindParam(':relation_of_patient', $relation_of_patient);
        $addPatientStmt->bindParam(':att_age', $att_age);
        $addPatientStmt->bindParam(':att_gender', $att_gender);
        $addPatientStmt->bindParam(':att_phone_number', $att_phone_number);

        if ($addPatientStmt->execute()) {
            $response['addpatient_inserted'] = true;
        } else {
            $response['addpatient_inserted'] = false;
            $response['error_inserting_addpatient'] = $addPatientStmt->errorInfo();
        }


        // Insert into p_profile table
        $sqlInsertPProfile = "
        INSERT INTO p_profile (patient_id, name, age, gender, phone_number)
        VALUES (:patient_id, :name, :age, :gender, :phone_number)
        ";
        $pProfileStmt = $conn->prepare($sqlInsertPProfile);
        $pProfileStmt->bindParam(':patient_id', $patient_id);
        $pProfileStmt->bindParam(':name', $name);
        $pProfileStmt->bindParam(':age', $age);
        $pProfileStmt->bindParam(':gender', $gender);
        $pProfileStmt->bindParam(':phone_number', $phone_number);

        if ($pProfileStmt->execute()) {
            $response['p_profile_inserted'] = true;
        } else {
            $response['p_profile_inserted'] = false;
            $response['error_inserting_p_profile'] = $pProfileStmt->errorInfo();
        }

        
    } catch (PDOException $e) {
        $response['error'] = true;
        $response['message'] = $e->getMessage();
    }
} else {
    $response['error'] = true;
    $response['message'] = "Invalid request method";
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);
