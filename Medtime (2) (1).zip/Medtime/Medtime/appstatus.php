<?php
require("dbh.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if "patient_id" exists in the form data
    if (isset($_POST["patient_id"])) {
        $patient_id = $_POST["patient_id"];

        // Continue with your code using PDO for database operations
        $stmt = $conn->prepare("SELECT * FROM appointment WHERE patient_id = :patient_id");
        $stmt->bindParam(':patient_id', $patient_id);
        
        if ($stmt->execute()) {
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(array("data" => $data));
        } else {
            echo json_encode(array("message" => "Database query error"));
        }
    } else {
        echo json_encode(array("message" => "Invalid form data: 'patient_id' key not found"));
    }
} else {
    echo json_encode(array("message" => "Invalid request method"));
}
?>