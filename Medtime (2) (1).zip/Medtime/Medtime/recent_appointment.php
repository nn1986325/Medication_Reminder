<?php
$host = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "Medtime"; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

require_once('dbh.php'); // This line is redundant and can be removed.

try {
    $loginqry = "SELECT patient_id, name, issue, date FROM appointment ORDER BY patient_id DESC LIMIT 1";
    
    $stmt = $pdo->query($loginqry);

    $student = array();

    if ($stmt->rowCount() > 0) {
        $i = 0;
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $student[$i]['patient_id'] = $row['patient_id'];
            $student[$i]['name'] = $row['name'];
            $student[$i]['issue'] = $row['issue'];
            $student[$i]['date'] = $row['date'];
            $i++;
        }
        $response['status'] = true;
        $response['message'] = "Top 1 most recently added appointment";
        $response['data'] = $student;
    } else {
        $response['status'] = false;
        $response['message'] = "No Data";
    }
} catch(PDOException $e) {
    // If an error occurs, catch it and store the error message in the response
    $response['status'] = false;
    $response['message'] = 'Error: ' . $e->getMessage();
}

// Set header and echo response
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
