<?php
        $requestArray = array(
            'apiKey' => '*******....', //Your API key
            'all' => true
        );
        $json = json_encode($requestArray);
        if( $curl = curl_init() ) {
            curl_setopt($curl, CURLOPT_URL, 'https://in.effebot.com/apiCalls/getPhones');
            curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $json);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'accept: application/json'));
            curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
            $out = curl_exec($curl);
            echo $out;
            curl_close($curl);
        }
    ?>