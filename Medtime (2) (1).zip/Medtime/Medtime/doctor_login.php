<?php
include("dbh.php");

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['doctor_id']) && isset($_POST['password'])) {
        $doctor_id = $_POST['doctor_id'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM `doctor_login` WHERE `doctor_id` = :doctor_id AND `password` = :password";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':doctor_id', $doctor_id, PDO::PARAM_STR);
        $stmt->bindParam(':password', $password, PDO::PARAM_STR);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            $response['success'] = true;
            $response['message'] = "Login successful!";
        } else {
            $response['success'] = false;
            $response['message'] = "Invalid doctor_id or password";
        }

        $stmt->closeCursor(); // Close the database cursor
    } else {
        $response['success'] = false;
        $response['message'] = "doctor_id and password parameters are required in the POST request data.";
    }
} else {
    $response['success'] = false;
    $response['message'] = "This endpoint only supports POST requests.";
}

header('Content-Type: application/json');
echo json_encode($response);
?>
