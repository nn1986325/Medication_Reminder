<?php
// Your database connection
require 'dbh.php'; // Ensure you have the database connection established in dbh.php

// Check for POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json'); // Set the header for JSON response

    // Assuming the patient_id is sent in the POST request
    $patient_id = $_POST['patient_id'] ?? null;

    if ($patient_id) {
        $response = array(); // Initialize an empty array for the JSON response

        try {
            // Fetch medication details for a specific patient_id
            $query = "SELECT medication_name, first_intake, second_intake, third_intake, before_food, after_food FROM medication WHERE patient_id = :patient_id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':patient_id', $patient_id);
            $stmt->execute();

            $medicationDetails = array(); // Initialize an array to store medication details
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $firstTiming = $row['first_intake'];
                $secondTiming = $row['second_intake'];
                $thirdTiming = $row['third_intake'];
                $medicationName = $row['medication_name'];
                $beforeFood = $row['before_food'];
                $afterFood = $row['after_food'];

                if ($firstTiming !== '00:00:00') {
                    $medicationDetails['first_intake'][] = array(
                        'medication_name' => $medicationName,
                        'before_food' => $beforeFood,
                        'after_food' => $afterFood,
                        'Timing' => date('h:i A', strtotime($firstTiming)) // Convert to 12-hour format (AM/PM)
                    );
                }
                if ($secondTiming !== '00:00:00') {
                    $secondTimingFormatted = date('h:i A', strtotime($secondTiming)); // Convert to 12-hour format (AM/PM)
                    // Convert AM to PM and PM to AM
                    if (date('A', strtotime($secondTiming)) === 'AM') {
                        $secondTimingFormatted = date('h:i A', strtotime($secondTiming . ' +12 hours')); // Add 12 hours to convert to PM
                    } else {
                        $secondTimingFormatted = date('h:i A', strtotime($secondTiming . ' -12 hours')); // Subtract 12 hours to convert to AM
                    }
                    $medicationDetails['second_intake'][] = array(
                        'medication_name' => $medicationName,
                        'before_food' => $beforeFood,
                        'after_food' => $afterFood,
                        'Timing' => $secondTimingFormatted
                    );
                }
                if ($thirdTiming !== '00:00:00') {
                    $thirdTimingFormatted = date('h:i A', strtotime($thirdTiming)); // Convert to 12-hour format (AM/PM)
                    // Convert AM to PM and PM to AM
                    if (date('A', strtotime($thirdTiming)) === 'AM') {
                        $thirdTimingFormatted = date('h:i A', strtotime($thirdTiming . ' +12 hours')); // Add 12 hours to convert to PM
                    } else {
                        $thirdTimingFormatted = date('h:i A', strtotime($thirdTiming . ' -12 hours')); // Subtract 12 hours to convert to AM
                    }
                    $medicationDetails['third_intake'][] = array(
                        'medication_name' => $medicationName,
                        'before_food' => $beforeFood,
                        'after_food' => $afterFood,
                        'Timing' => $thirdTimingFormatted
                    );
                }
            }

            $response['medication_details'] = $medicationDetails;
        } catch (PDOException $e) {
            $response['error'] = "Error: " . $e->getMessage();
        }

        // Close the database connection
        $conn = null;

        echo json_encode($response); // Convert the response array to JSON and echo it
    } else {
        echo json_encode(array('error' => 'Invalid or missing patient_id.'));
    }
} else {
    echo json_encode(array('error' => 'Invalid request method. Please use POST.'));
}
?>
