<?php
// Include the database connection configuration
include("dbh.php");

// Create an associative array to hold the API response
$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Assume patient_id for comparison
        $patient_id = $_POST['patient_id'];

        // Check if other necessary fields are present for update
        if (isset($_POST['patient_id']) && isset($_POST['name']) & isset($_POST['age']) & isset($_POST['gender'])& isset($_POST['phone_number'])) {
            $patient_id = $_POST['patient_id'];
            $name = $_POST['name'];
            $age = $_POST['age'];
            $gender = $_POST['gender'];
            $phone_number = $_POST['phone_number'];

            // Update data in p_profile table by patient_id
            $updatePProfileSql = "UPDATE `p_profile` SET `patient_id` = :patient_id, `name` = :name, `age` = :age, `gender` = :gender, `phone_number` = :phone_number WHERE `patient_id` = :patient_id";
            $stmtUpdatePProfile = $conn->prepare($updatePProfileSql);
            $stmtUpdatePProfile->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
            $stmtUpdatePProfile->bindParam(':name', $name, PDO::PARAM_STR);
            $stmtUpdatePProfile->bindParam(':age', $age, PDO::PARAM_STR);
            $stmtUpdatePProfile->bindParam(':gender', $gender, PDO::PARAM_STR);
            $stmtUpdatePProfile->bindParam(':phone_number', $phone_number, PDO::PARAM_STR);
            
            if ($stmtUpdatePProfile->execute()) {
                $response['success'] = true;
                $response['message'] = "Data updated successfully in 'p_profile' table";
            } else {
                $response['success'] = false;
                $response['message'] = "Error updating data in 'p_profile' table";
            }
        } else {
            $response['success'] = false;
            $response['message'] = "Required fields for update are missing";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Invalid request method";
    }
} catch (PDOException $e) {
    // Handle any exceptions
    $response['success'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn = null;
?>
