<?php
require("dbh.php");

// Check if the request method is POST and the request contains a JSON payload
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Check if the required fields are present in the JSON data
    if (isset($_POST["patient_id"]) && isset($_POST["name"]) && isset($_POST["issue"]) && isset($_POST["date"])) {
        $patient_id = $_POST["patient_id"];
        $name = $_POST["name"];
        $issue = $_POST["issue"];
        $date = $_POST["date"];
        $status = "pending";

        $sql = "INSERT INTO appointment (patient_id, name, issue, date, status) VALUES (:patient_id, :name, :issue, :date, :status)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':patient_id', $patient_id);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':issue', $issue);
        $stmt->bindParam(':date', $date);
        $stmt->bindParam(':status', $status);

        if ($stmt->execute()) {
            $response = array('status' => 'success', 'message' => 'Data inserted successfully');
            echo json_encode($response);
        } else {
            $response = array('status' => 'failure', 'message' => 'Data not inserted');
            echo json_encode($response);
        }
    } else {
        $response = array('status' => 'failure', 'message' => 'Missing required fields in JSON data');
        echo json_encode($response);
    }
} else {
    $response = array('status' => 'failure', 'message' => 'Invalid JSON data');
    echo json_encode($response);
}
?>
