<?php
require("dbh.php");

// Check if the request method is POST and the request contains a JSON payload
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data1 = json_decode($json, true);
    print_r($data1);

    $data = array();
    // Perform the database query to select data from the appointment table where status is 'Approved'
    $sql = "SELECT * FROM appointment WHERE status='Approved'";

    try {
        // Prepare the query
        $stmt = $conn->prepare($sql);
        
        // Execute the query
        $stmt->execute();

        // Fetch data from the database and add it to the array
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Return the data as JSON
        echo json_encode($data, JSON_PRETTY_PRINT);
    } catch (PDOException $e) {
        $response = array('status' => 'failure', 'message' => 'Data retrieval failed: ' . $e->getMessage());
        echo json_encode($response);
    }
} else {
    $response = array('status' => 'failure', 'message' => 'Missing required fields in JSON data');
    echo json_encode($response);
}
?>
