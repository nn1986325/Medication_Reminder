<?php
// Include the database connection configuration
include("dbh.php");

// Create an associative array to hold the API response
$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Assume patient_id for comparison
        $patient_id = $_POST['patient_id'];

        // Fetch data from p_profile table by patient_id
        $selectPProfileSql = "SELECT * FROM `p_profile` WHERE `patient_id` = :patient_id";
        $stmtSelectPProfile = $conn->prepare($selectPProfileSql);
        $stmtSelectPProfile->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
        $stmtSelectPProfile->execute();

        if ($stmtSelectPProfile->rowCount() > 0) {
            // Fetch the data
            $profileData = $stmtSelectPProfile->fetch(PDO::FETCH_ASSOC);

            // Fetch image from the image table by patient_id
            $selectImageSql = "SELECT * FROM `image` WHERE `patient_id` = :patient_id";
            $stmtSelectImage = $conn->prepare($selectImageSql);
            $stmtSelectImage->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
            $stmtSelectImage->execute();

            if ($stmtSelectImage->rowCount() > 0) {
                // Fetch the image data
                $imageData = $stmtSelectImage->fetch(PDO::FETCH_ASSOC);

                // Add image data to profile data
                $profileData['image'] = $imageData['image'];

                $response['success'] = true;
                $response['data'] = $profileData;
                $response['message'] = "Data retrieved successfully from 'p_profile' and 'image' tables";
            } else {
                $response['success'] = false;
                $response['message'] = "Error: Image not found for the patient ID in 'image' table";
            }
        } else {
            $response['success'] = false;
            $response['message'] = "Error: Patient ID not found in 'p_profile' table";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Invalid request method";
    }
} catch (PDOException $e) {
    // Handle any exceptions
    $response['success'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn = null;
?>
