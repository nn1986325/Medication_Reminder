<?php
require("dbh.php");

// Check if the request method is POST and the request contains a JSON payload
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Check if the required fields are present in the JSON data
    if (isset($_POST["patient_id"])) {
        $pid = $_POST["patient_id"];
        $status = "Approved";

        // Prepare the SQL query
        $sql = "UPDATE appointment SET status = :status WHERE patient_id = :patient_id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':patient_id', $pid);

        // Execute the query
        if ($stmt->execute()) {
            $response = array('status' => 'success', 'message' => 'Appointment Accepted Successfully');
            echo json_encode($response);
        } else {
            $response = array('status' => 'failure', 'message' => 'Data not updated');
            echo json_encode($response);
        }
    } else {
        $response = array('status' => 'failure', 'message' => 'Missing required fields in JSON data');
        echo json_encode($response);
    }
} else {
    $response = array('status' => 'failure', 'message' => 'Invalid JSON data');
    echo json_encode($response);
}
?>
