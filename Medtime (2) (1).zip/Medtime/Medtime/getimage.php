<?php
$host = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "Medtime"; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Initialize an array to store the data
    $imageData = array();

    // Fetch data from 'questions' table
    $questionsQuery = "SELECT patient_id, image FROM image";
    $stmt = $pdo->query($questionsQuery);

    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            // Store the patient_id, and image URL in the array
            $imageData[] = array(
                'patient_id' => $row['patient_id'],
                'image' => $row['image']
            );
        }
        
        // Output the data as JSON
        $response = array(
            'status' => 'success',
            'data' => $imageData
        );
    } else {
        // Handle case where no data is found
        $response = array(
            'status' => 'failure',
            'message' => 'No data found'
        );
    }
} catch(PDOException $e) {
    // If an error occurs, catch it and echo the error message
    $response = array(
        'status' => 'failure',
        'message' => 'Error: ' . $e->getMessage()
    );
}

// Output the JSON response
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$pdo = null;
?>