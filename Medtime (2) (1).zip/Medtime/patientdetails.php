<?php
require("dbh.php");

// Check if the request method is POST and 'patient_id' is set
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['patient_id'])) {
    $patient_id = $_POST['patient_id'];

    try {
        // Prepare a statement to select data from patientdetails table
        $stmt = $conn->prepare("SELECT * FROM patientdetails WHERE patient_id = :patient_id");
        $stmt->bindParam(':patient_id', $patient_id);
        $stmt->execute();

        // Fetch data as an associative array
        $dataRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Check if there are results
        if ($dataRows) {
            // Prepare a statement to select image from image table
            $stmtImage = $conn->prepare("SELECT image FROM image WHERE patient_id = :patient_id");
            $stmtImage->bindParam(':patient_id', $patient_id);
            $stmtImage->execute();

            // Fetch image data
            $imageData = $stmtImage->fetch(PDO::FETCH_ASSOC);

            // Add image data to the fetched data
            if ($imageData) {
                $dataRows[0]['image'] = $imageData['image'];
            } else {
                // Set image to empty string if not found
                $dataRows[0]['image'] = '';
            }

            // Construct the response array with success flag and data
            $response = array(
                'success' => true,
                'data' => $dataRows
            );

            // Convert response array to JSON format
            $jsonResponse = json_encode($response);

            // Output the JSON response
            header('Content-Type: application/json');
            echo $jsonResponse;
        } else {
            // Construct the response array with success flag and message
            $response = array(
                'success' => false,
                'message' => "No data found for the patient ID: $patient_id"
            );

            // Convert response array to JSON format
            $jsonResponse = json_encode($response);

            // Output the JSON response
            header('Content-Type: application/json');
            echo $jsonResponse;
        }
    } catch (PDOException $e) {
        // Handle PDO errors
        echo "Error: " . $e->getMessage();
    }
} else {
    // Handle if 'patient_id' is not set in the POST request or if it's not a POST request
    echo "Patient ID not found in the request or invalid request method";
}
?>
