<?php
// Include the database connection configuration
include("dbh.php");

// Create an associative array to hold the API response
$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Assume these values for patient_id, new_password, and confirm_password
        $patient_id = $_POST['patient_id'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        // Check if patient_id exists in user table
        $checkUserSql = "SELECT * FROM `user` WHERE `patient_id` = :patient_id";
        $stmtCheckUser = $conn->prepare($checkUserSql);
        $stmtCheckUser->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
        $stmtCheckUser->execute();

        if ($stmtCheckUser->rowCount() > 0) {
            // Patient ID exists in user table, perform update
            $sqlUpdateUser = "UPDATE `user` SET `password` = :new_password WHERE `patient_id` = :patient_id";
            $stmtUpdateUser = $conn->prepare($sqlUpdateUser);
            $stmtUpdateUser->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
            $stmtUpdateUser->bindParam(':new_password', $new_password, PDO::PARAM_STR);
            $stmtUpdateUser->execute();

            // Check if patient_id exists in forgot_password table
            $checkForgotPasswordSql = "SELECT * FROM `forgot_password` WHERE `patient_id` = :patient_id";
            $stmtCheckForgotPassword = $conn->prepare($checkForgotPasswordSql);
            $stmtCheckForgotPassword->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
            $stmtCheckForgotPassword->execute();

            if ($stmtCheckForgotPassword->rowCount() > 0) {
                // Patient ID exists in forgot_password table, perform update
                $sqlUpdateForgotPassword = "UPDATE `forgot_password` SET `new_password` = :new_password, `confirm_password` = :confirm_password WHERE `patient_id` = :patient_id";
                $stmtUpdateForgotPassword = $conn->prepare($sqlUpdateForgotPassword);
                $stmtUpdateForgotPassword->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
                $stmtUpdateForgotPassword->bindParam(':new_password', $new_password, PDO::PARAM_STR);
                $stmtUpdateForgotPassword->bindParam(':confirm_password', $confirm_password, PDO::PARAM_STR);
                $stmtUpdateForgotPassword->execute();

                $response['success'] = true;
                $response['message'] = "Password Updated Successfully
                ";
            } else {
                // Patient ID not found in forgot_password table, insert a new record
                $sqlInsertForgotPassword = "INSERT INTO `forgot_password` (`patient_id`, `new_password`, `confirm_password`) VALUES (:patient_id, :new_password, :confirm_password)";
                $stmtInsertForgotPassword = $conn->prepare($sqlInsertForgotPassword);
                $stmtInsertForgotPassword->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
                $stmtInsertForgotPassword->bindParam(':new_password', $new_password, PDO::PARAM_STR);
                $stmtInsertForgotPassword->bindParam(':confirm_password', $confirm_password, PDO::PARAM_STR);
                $stmtInsertForgotPassword->execute();

                $response['success'] = true;
                $response['message'] = "Record inserted in 'forgot_password' table";
            }
        } else {

            // Insert a new record in forgot_password table
            $sqlInsertForgotPassword = "INSERT INTO `forgot_password` (`patient_id`, `new_password`, `confirm_password`) VALUES (:patient_id, :new_password, :confirm_password)";
            $stmtInsertForgotPassword = $conn->prepare($sqlInsertForgotPassword);
            $stmtInsertForgotPassword->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
            $stmtInsertForgotPassword->bindParam(':new_password', $new_password, PDO::PARAM_STR);
            $stmtInsertForgotPassword->bindParam(':confirm_password', $confirm_password, PDO::PARAM_STR);
            $stmtInsertForgotPassword->execute();

            $response['success'] = true;
            $response['message'] = "Record inserted in 'user' and 'forgot_password' tables";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Invalid request method";
    }
} catch (PDOException $e) {
    // Handle any exceptions
    $response['success'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn = null;
?>
