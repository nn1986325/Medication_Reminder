<?php
// Include database connection
include("dbh.php");

$response = array(); // Initialize an array to hold the response data

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you receive the necessary parameters in the POST request
    // Adjust these as per your form or JSON payload
    $patient_id = $_POST['patient_id'];
    $name = $_POST['name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $phone_number = $_POST['phone_number'];
    $Treatment = $_POST['Treatment'];
    $BP = $_POST['BP'];
    $TSH = $_POST['TSH'];
    $RBS = $_POST['RBS'];
    $FBS = $_POST['FBS'];
    $ppbs = $_POST['ppbs'];
    $HbA1c = $_POST['HbA1c'];
    $attender_name = $_POST['attender_name'];
    $relation_of_patient = $_POST['relation_of_patient'];
    $att_age = $_POST['att_age'];
    $att_gender = $_POST['att_gender'];
    $att_phone_number = $_POST['att_phone_number'];

    try {
        // Check if the patient_id exists in the database
        $checkStmt = $conn->prepare("SELECT COUNT(*) FROM patientdetails WHERE patient_id = :patient_id");
        $checkStmt->bindParam(':patient_id', $patient_id);
        $checkStmt->execute();
        $count = $checkStmt->fetchColumn();

        if ($count > 0) {
            // Update existing record
            $sql = "UPDATE patientdetails SET name = :name, age = :age, gender = :gender, phone_number = :phone_number, 
                    Treatment = :Treatment, BP = :BP, TSH = :TSH, RBS = :RBS, FBS = :FBS, ppbs = :ppbs, HbA1c = :HbA1c, 
                    attender_name = :attender_name, relation_of_patient = :relation_of_patient, att_age = :att_age, 
                    att_gender = :att_gender, att_phone_number = :att_phone_number WHERE patient_id = :patient_id";
        } else {
            // Insert new record
            $sql = "INSERT INTO patientdetails (patient_id, name, age, gender, phone_number, Treatment, BP, TSH, RBS, FBS, ppbs, HbA1c, 
                    attender_name, relation_of_patient, att_age, att_gender, att_phone_number) VALUES 
                    (:patient_id, :name, :age, :gender, :phone_number, :Treatment, :BP, :TSH, :RBS, :FBS, :ppbs, :HbA1c, 
                    :attender_name, :relation_of_patient, :att_age, :att_gender, :att_phone_number)";
        }

        // Prepare and execute the SQL statement
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':patient_id', $patient_id);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':age', $age);
        $stmt->bindParam(':gender', $gender);
        $stmt->bindParam(':phone_number', $phone_number);
        $stmt->bindParam(':Treatment', $Treatment);
        $stmt->bindParam(':BP', $BP);
        $stmt->bindParam(':TSH', $TSH);
        $stmt->bindParam(':RBS', $RBS);
        $stmt->bindParam(':FBS', $FBS);
        $stmt->bindParam(':ppbs', $ppbs);
        $stmt->bindParam(':HbA1c', $HbA1c);
        $stmt->bindParam(':attender_name', $attender_name);
        $stmt->bindParam(':relation_of_patient', $relation_of_patient);
        $stmt->bindParam(':att_age', $att_age);
        $stmt->bindParam(':att_gender', $att_gender);
        $stmt->bindParam(':att_phone_number', $att_phone_number);

        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = ($count > 0) ? "Patient details updated successfully" : "New patient details inserted successfully";
            
            // Retrieve the latest HbA1c value for this patient_id
            $latestHbA1cQuery = "SELECT HbA1c FROM patientdetails WHERE patient_id = :patient_id";
            $latestHbA1cStmt = $conn->prepare($latestHbA1cQuery);
            $latestHbA1cStmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
            $latestHbA1cStmt->execute();
            $latestHbA1cResult = $latestHbA1cStmt->fetch(PDO::FETCH_ASSOC);
            $latestHbA1c = $latestHbA1cResult['HbA1c'];
            
            // Insert patient_id and HbA1c into the graph table
            $insertGraphSql = "INSERT INTO graph (patient_id, HbA1c) VALUES (:patient_id, :HbA1c)";
            $insertGraphStmt = $conn->prepare($insertGraphSql);
            $insertGraphStmt->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
            $insertGraphStmt->bindParam(':HbA1c', $latestHbA1c, PDO::PARAM_STR);
            
            if ($insertGraphStmt->execute()) {
                $response['message'] .= " Diabetes level graph updated successfully.";
            } else {
                $errorInfo = $insertGraphStmt->errorInfo();
                $response['success'] = false;
                $response['message'] .= " Failed to insert into graph. Error: " . $errorInfo[2];
            }
        } else {
            $response['error'] = true;
            $response['message'] = "Failed to update/insert patient details";
        }
        
        
    } catch (PDOException $e) {
        $response['error'] = true;
        $response['message'] = $e->getMessage();
    }
} else {
    $response['error'] = true;
    $response['message'] = "Invalid request method";
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn = null;
?>
