<?php
require("dbh.php");

$response = array();

// Check if 'patient_id' parameter is set
if (isset($_POST['patient_id'])) {
    // Retrieve the 'patient_id' parameter value
    $patient_id = $_POST['patient_id'];

    try {
        // Prepare the SQL query to fetch HbA1c values along with dates
        $sql_select = "SELECT HbA1c, DATE_FORMAT(date, '%d-%m') AS date
                       FROM graph
                       WHERE patient_id = :patient_id";
        $stmt_select = $conn->prepare($sql_select);
        $stmt_select->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);

        // Execute the prepared statement
        $stmt_select->execute();

        // Fetch all results as an associative array
        $results = $stmt_select->fetchAll(PDO::FETCH_ASSOC);

        if ($results) {
            $response['status'] = "success";
            $response['message'] = "Data found";
            $response['HbA1c_dates'] = $results;
        } else {
            $response['status'] = "error";
            $response['message'] = "No results found for the given patient ID";
        }

        // Check if 'HbA1c' parameter is set
        if (isset($_POST['HbA1c'])) {
            // Retrieve the 'HbA1c' parameter value
            $HbA1c_value = $_POST['HbA1c'];

            // Prepare the SQL query to insert new data with the current date
            $sql_insert = "INSERT INTO graph (HbA1c, patient_id) VALUES (:HbA1c, :patient_id)";
            $stmt_insert = $conn->prepare($sql_insert);
            $stmt_insert->bindParam(':HbA1c', $HbA1c_value, PDO::PARAM_STR);
            $stmt_insert->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
            
            // Execute the prepared statement and handle errors
            if ($stmt_insert->execute()) {
                $response['status'] = "success";
                $response['message'] = "Data inserted successfully";
            } else {
                $response['status'] = "error";
                $response['message'] = "Error inserting data: " . implode(", ", $stmt_insert->errorInfo());
            }
        }
    } catch (PDOException $e) {
        // Handle PDO exceptions
        $response['status'] = "error";
        $response['message'] = "PDO Exception: " . $e->getMessage();
    }
} else {
    // If 'patient_id' parameter is not set, handle the error accordingly
    $response['status'] = "error";
    $response['message'] = "'patient_id' parameter not found in the request.";
}

// Convert PHP array to JSON and output the response
echo json_encode($response);
?>
