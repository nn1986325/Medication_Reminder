<?php
// Include database connection
require("dbh.php");

// Initialize response array
$response = array();

// Check if the required parameter is set in the POST request
if (isset($_POST["patient_id"])) {
    // Assign POST value to variable
    $patient_id = $_POST["patient_id"];

    try {
        // Prepare SQL statement to select data from the notification table
        $sql = "SELECT * FROM notification WHERE patient_id = :patient_id";
        $stmt = $conn->prepare($sql);

        // Bind parameter to SQL statement
        $stmt->bindParam(':patient_id', $patient_id);

        // Execute SQL statement
        $stmt->execute();

        // Fetch result
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Check if any rows are returned
        if ($result) {
            $response['status'] = 'success';
            $response['data'] = $result;
        } else {
            $response['status'] = 'error';
            $response['message'] = 'No notification details found for the given patient ID.';
        }
    } catch (PDOException $e) {
        // Handle any PDO exceptions
        $response['status'] = 'error';
        $response['message'] = 'PDO Exception: ' . $e->getMessage();
    }
} else {
    // Error response for missing parameter in the POST request
    $response['status'] = 'error';
    $response['message'] = 'Required parameter (patient_id) is missing in the POST request.';
}

// Convert response array to JSON and output
header('Content-Type: application/json');
echo json_encode($response);
?>
