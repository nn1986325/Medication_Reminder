package com.example.medtime;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class p_fgt_pswd extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pfgt_pswd);
    }
}