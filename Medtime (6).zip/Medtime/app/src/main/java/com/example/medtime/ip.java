package com.example.medtime;

public class ip {

    static String ipn ="http://192.168.116.114/Medtime/";
}
