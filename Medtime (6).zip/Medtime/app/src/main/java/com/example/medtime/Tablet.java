package com.example.medtime;

public class Tablet {
    private String name,mrng;



    public Tablet(String name,  String mrng) {
        this.name = name;

        this.mrng = mrng;


    }

    public String getName() {
        return name;
    }
    public String getmrng() {
        return mrng;
    }
}
